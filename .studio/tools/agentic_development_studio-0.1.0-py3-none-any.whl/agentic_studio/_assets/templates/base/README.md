# {{PROJECT_NAME}}

This project uses Agentic Development Studio's Codex-native Stage One workflow.

Bootstrap the pinned local runtime with `./studioctl bootstrap`, run
`./studioctl doctor`, then initialize or explicitly import a run. Inspect it with
`./studioctl status` and follow `docs/project-guide/first-discovery-prompt.md`.
