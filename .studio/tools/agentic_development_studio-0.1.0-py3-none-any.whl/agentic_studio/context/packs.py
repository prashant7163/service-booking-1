from __future__ import annotations

import hashlib

from agentic_studio.contracts import (
    ContextOmission,
    ContextPack,
    ContextPackManifest,
    ContextPackSection,
    ContextQuery,
)

from .index import IndexSnapshot
from .redaction import RedactionEngine
from .retrieval import LexicalRetriever


class ContextPackBuilder:
    def __init__(self) -> None:
        self.retriever = LexicalRetriever()
        self.redactor = RedactionEngine()

    def build(self, query: ContextQuery, snapshot: IndexSnapshot) -> ContextPack:
        hits = self.retriever.retrieve(query, snapshot)
        records = {record.path: record for record in snapshot.records}
        sections: list[ContextPackSection] = []
        omissions: list[ContextOmission] = []
        byte_count = 0
        redaction_count = 0
        for hit in hits:
            content = hit.content or ""
            redaction = self.redactor.redact(content, hit.path)
            if redaction.blocked:
                omissions.append(ContextOmission(path=hit.path, reason="sensitive_blocked"))
                continue
            size = len(redaction.content.encode("utf-8"))
            if byte_count + size > query.byte_budget:
                omissions.append(ContextOmission(path=hit.path, reason="byte_budget"))
                continue
            redaction_count += records[hit.path].redaction_count + len(redaction.findings)
            sections.append(
                ContextPackSection(
                    hit_id=hit.hit_id,
                    path=hit.path,
                    content=redaction.content,
                    content_hash=hashlib.sha256(redaction.content.encode("utf-8")).hexdigest(),
                    authority_tier=hit.authority_tier,
                )
            )
            byte_count += size
        digest_material = "\n".join(
            f"{section.path}\0{section.content_hash}" for section in sections
        )
        pack_digest = hashlib.sha256(digest_material.encode("utf-8")).hexdigest()
        manifest = ContextPackManifest(
            schema_version="1.0.0",
            manifest_id=f"manifest-{query.query_id}",
            query_id=query.query_id,
            source_revision=query.source_revision,
            index_revision=snapshot.revision,
            providers_attempted=[provider.value for provider in query.provider_policy],
            providers_used=["lexical"] if hits else [],
            included_sources=[section.path for section in sections],
            omitted_sources=omissions,
            byte_budget=query.byte_budget,
            byte_count=byte_count,
            redaction_count=redaction_count,
            outbound_destination="model",
            policy_decision="allowed",
            pack_digest=pack_digest,
        )
        return ContextPack(
            schema_version="1.0.0",
            pack_id=f"pack-{query.query_id}",
            manifest=manifest,
            sections=sections,
        )
