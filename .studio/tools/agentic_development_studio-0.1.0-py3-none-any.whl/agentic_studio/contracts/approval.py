from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence
from datetime import UTC, datetime
from enum import StrEnum
from math import isfinite
from typing import Any, Self, SupportsIndex, cast, overload

from pydantic import (
    AwareDatetime,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    field_validator,
    model_serializer,
)

from .base import ContractModel

type FrozenJsonValue = str | int | float | bool | _FrozenJsonMapping | _FrozenJsonSequence | None


class _FrozenJsonMapping(Mapping[str, FrozenJsonValue]):
    __slots__ = ("_items",)
    _items: tuple[tuple[str, FrozenJsonValue], ...]

    def __init__(self, items: tuple[tuple[str, FrozenJsonValue], ...]) -> None:
        object.__setattr__(self, "_items", items)

    def __setattr__(self, name: str, value: object) -> None:
        if name == "_items":
            raise AttributeError("immutable JSON values cannot be reassigned")
        object.__setattr__(self, name, value)

    def __getitem__(self, key: str) -> FrozenJsonValue:
        for item_key, value in self._items:
            if item_key == key:
                return value
        raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        return (key for key, _ in self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __copy__(self) -> Self:
        return self

    def __deepcopy__(self, memo: dict[int, Any]) -> Self:
        return self


class _FrozenJsonSequence(Sequence[FrozenJsonValue]):
    __slots__ = ("_items",)
    _items: tuple[FrozenJsonValue, ...]

    def __init__(self, items: tuple[FrozenJsonValue, ...]) -> None:
        object.__setattr__(self, "_items", items)

    def __setattr__(self, name: str, value: object) -> None:
        if name == "_items":
            raise AttributeError("immutable JSON values cannot be reassigned")
        object.__setattr__(self, name, value)

    @overload
    def __getitem__(self, index: SupportsIndex) -> FrozenJsonValue: ...

    @overload
    def __getitem__(self, index: slice) -> Sequence[FrozenJsonValue]: ...

    def __getitem__(
        self,
        index: SupportsIndex | slice,
    ) -> FrozenJsonValue | Sequence[FrozenJsonValue]:
        return self._items[index]

    def __len__(self) -> int:
        return len(self._items)

    def __copy__(self) -> Self:
        return self

    def __deepcopy__(self, memo: dict[int, Any]) -> Self:
        return self


def _freeze_json(value: Any, active_ids: set[int]) -> FrozenJsonValue:
    if value is None or type(value) in {str, int, bool}:
        return cast(FrozenJsonValue, value)
    if type(value) is float:
        if not isfinite(value):
            raise ValueError("extra values must be JSON-compatible")
        return value
    if type(value) is dict:
        object_id = id(value)
        if object_id in active_ids:
            raise ValueError("extra values must be acyclic")
        active_ids.add(object_id)
        try:
            items: list[tuple[str, FrozenJsonValue]] = []
            for key, item in value.items():
                if type(key) is not str:
                    raise ValueError("extra values must be JSON-compatible")
                items.append((key, _freeze_json(item, active_ids)))
            return _FrozenJsonMapping(tuple(items))
        finally:
            active_ids.remove(object_id)
    if type(value) is list:
        object_id = id(value)
        if object_id in active_ids:
            raise ValueError("extra values must be acyclic")
        active_ids.add(object_id)
        try:
            return _FrozenJsonSequence(tuple(_freeze_json(item, active_ids) for item in value))
        finally:
            active_ids.remove(object_id)
    raise ValueError("extra values must be JSON-compatible")


def _freeze_extras(values: Mapping[str, Any]) -> _FrozenJsonMapping:
    return _FrozenJsonMapping(
        tuple((key, _freeze_json(value, set())) for key, value in values.items())
    )


def _thaw_json(value: FrozenJsonValue) -> Any:
    if isinstance(value, _FrozenJsonMapping):
        return {key: _thaw_json(item) for key, item in value.items()}
    if isinstance(value, _FrozenJsonSequence):
        return [_thaw_json(item) for item in value]
    return value


def _thaw_extras(values: Mapping[str, FrozenJsonValue]) -> dict[str, Any]:
    return {key: _thaw_json(value) for key, value in values.items()}


class ApprovalDecision(StrEnum):
    APPROVED = "approved"
    CHANGES_REQUESTED = "changes_requested"
    REJECTED = "rejected"


class Approval(ContractModel):
    model_config = ConfigDict(
        extra="allow",
        frozen=True,
        validate_default=True,
    )

    approval_id: str = Field(pattern=r"^apr-[a-z0-9][a-z0-9-]{2,63}$")
    subject_type: str = Field(min_length=1, max_length=80)
    subject_id: str = Field(min_length=1, max_length=120)
    subject_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    decision: ApprovalDecision
    decided_by: str = Field(min_length=1, max_length=120)
    decided_at: AwareDatetime
    comment: str | None = Field(default=None, max_length=2000)

    def model_post_init(self, __context: Any) -> None:
        if self.__pydantic_extra__ is not None:
            object.__setattr__(self, "__pydantic_extra__", _freeze_extras(self.__pydantic_extra__))

    @model_serializer(mode="wrap")
    def serialize_model(self, handler: SerializerFunctionWrapHandler) -> Any:
        serialization_copy = super().__copy__()
        if self.__pydantic_extra__ is not None:
            object.__setattr__(
                serialization_copy,
                "__pydantic_extra__",
                _thaw_extras(self.__pydantic_extra__),
            )
        return handler(serialization_copy)

    def __copy__(self) -> Self:
        return type(self).model_validate(self.model_dump(mode="json", round_trip=True))

    def __deepcopy__(self, memo: dict[int, Any] | None = None) -> Self:
        return type(self).model_validate(self.model_dump(mode="json", round_trip=True))

    def model_copy(
        self,
        *,
        update: Mapping[str, Any] | None = None,
        deep: bool = False,
    ) -> Self:
        payload = self.model_dump(mode="json", round_trip=True)
        if update is not None:
            payload.update(update)
        return type(self).model_validate(payload)

    @field_validator("decided_at")
    @classmethod
    def normalize_utc(cls, value: datetime) -> datetime:
        return value.astimezone(UTC)
