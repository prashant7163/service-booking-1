import hashlib
import json
from typing import Final

from pydantic import BaseModel, ConfigDict, Field, field_validator

SUPPORTED_CONTRACT_MAJOR: Final = 1
SEMVER_PATTERN: Final = (
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-(?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*)"
    r"(?:\.(?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*))*)?"
    r"(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$"
)


class StudioModel(BaseModel):
    model_config = ConfigDict(
        extra="allow",
        validate_assignment=True,
        validate_default=True,
    )

    def canonical_json(self, *, exclude: set[str] | None = None) -> str:
        payload = self.model_dump(mode="json", by_alias=True, exclude=exclude, exclude_none=True)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)

    def sha256_digest(self, *, exclude: set[str] | None = None) -> str:
        return hashlib.sha256(self.canonical_json(exclude=exclude).encode("utf-8")).hexdigest()


class ContractModel(StudioModel):
    schema_version: str = Field(pattern=SEMVER_PATTERN)

    @field_validator("schema_version")
    @classmethod
    def reject_unsupported_major(cls, value: str) -> str:
        if int(value.split(".", maxsplit=1)[0]) != SUPPORTED_CONTRACT_MAJOR:
            raise ValueError(f"unsupported schema major: {value}")
        return value
