from __future__ import annotations

from collections.abc import Iterator
from enum import StrEnum
from pathlib import PurePosixPath
from typing import Any, Self

from pydantic import Field, model_validator

from .project_spec import (
    ProjectSpecification,
    StableId,
    _ImmutableContractModel,
    _ImmutableStudioModel,
)


class TaskKind(StrEnum):
    PLANNING = "planning"
    IMPLEMENTATION = "implementation"
    USER_REVIEW = "user_review"
    CODE_REVIEW = "code_review"
    BUILD = "build"
    QUALITY_ENGINEERING = "quality_engineering"
    INDEPENDENT_AUDIT = "independent_audit"

    @classmethod
    def required_gate_kinds(cls) -> tuple[Self, ...]:
        return (
            cls.USER_REVIEW,
            cls.CODE_REVIEW,
            cls.BUILD,
            cls.QUALITY_ENGINEERING,
            cls.INDEPENDENT_AUDIT,
        )


class MilestoneBoundary(StrEnum):
    SINGLE_ROLE = "single_role"
    CROSS_BOUNDARY = "cross_boundary"


class RiskLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


def _is_safe_repo_locator(value: str) -> bool:
    if not value or "\\" in value or value.startswith("/"):
        return False
    if len(value) >= 2 and value[0].isalpha() and value[1] == ":":
        return False
    path = PurePosixPath(value)
    return str(path) != "." and str(path) == value and ".." not in path.parts


class ArtifactReference(_ImmutableStudioModel):
    artifact_id: StableId
    locator: str = Field(min_length=1, max_length=500)
    schema_version: str = Field(pattern=r"^1\.\d+\.\d+$")
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_locator(self) -> Self:
        if not _is_safe_repo_locator(self.locator):
            raise ValueError("artifact locator must be repository-relative and non-escaping")
        return self


class WorkspaceAllocation(_ImmutableStudioModel):
    isolation_kind: str = Field(min_length=1, max_length=80)
    locator: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_locator(self) -> Self:
        if not _is_safe_repo_locator(self.locator):
            raise ValueError("workspace locator must be repository-relative and non-escaping")
        return self


class PlannedTask(_ImmutableStudioModel):
    task_id: StableId
    kind: TaskKind
    title: str = Field(min_length=1, max_length=500)
    requirement_ids: list[StableId]
    dependency_task_ids: list[StableId]
    owner_role: str = Field(min_length=1, max_length=120)
    owner_instance_id: StableId
    workspace: WorkspaceAllocation

    @model_validator(mode="after")
    def validate_assignment(self) -> Self:
        if self.kind is TaskKind.IMPLEMENTATION and self.owner_role in {
            "Code Reviewer",
            "Independent Auditor",
            "Build Manager",
            "Quality Engineer",
            "User",
        }:
            raise ValueError("incompatible owner role for implementation task")
        if self.kind is TaskKind.PLANNING and self.owner_role not in {
            "Architect",
            "Discovery Lead",
            "Orchestrator",
        }:
            raise ValueError("incompatible owner role for planning task")
        return self


class VerificationStep(_ImmutableStudioModel):
    verification_id: StableId
    kind: TaskKind
    title: str = Field(min_length=1, max_length=500)
    reviewer_role: str = Field(min_length=1, max_length=120)
    reviewer_instance_id: StableId
    producer_task_ids: list[StableId] = Field(min_length=1)
    applicable: bool = True
    applicability_reason: str | None = Field(default=None, min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_gate_role_and_applicability(self) -> Self:
        expected_roles = {
            TaskKind.USER_REVIEW: "User",
            TaskKind.CODE_REVIEW: "Code Reviewer",
            TaskKind.BUILD: "Build Manager",
            TaskKind.QUALITY_ENGINEERING: "Quality Engineer",
            TaskKind.INDEPENDENT_AUDIT: "Independent Auditor",
        }
        if self.kind not in expected_roles:
            raise ValueError("verification step kind must be a gate kind")
        if self.reviewer_role != expected_roles[self.kind]:
            raise ValueError("verification gate has incompatible reviewer role")
        if not self.applicable and self.applicability_reason is None:
            raise ValueError("not-applicable gate requires an applicability reason")
        if self.applicable and self.applicability_reason is not None:
            raise ValueError("applicable gate cannot have an applicability reason")
        return self


class MilestoneDefinition(_ImmutableStudioModel):
    milestone_id: StableId
    ordinal: int = Field(ge=1)
    objective: str = Field(min_length=1, max_length=500)
    requirement_ids: list[StableId] = Field(min_length=1)
    exit_criteria: list[str] = Field(min_length=1)
    proposed_demo: str = Field(min_length=1, max_length=500)
    risk_level: RiskLevel
    boundary: MilestoneBoundary
    affected_roles: list[str] = Field(min_length=1)
    tasks: list[PlannedTask] = Field(min_length=1)
    verification_steps: list[VerificationStep] = Field(min_length=1)


class MilestonePlan(_ImmutableContractModel):
    plan_id: StableId
    project_specification: ProjectSpecification | None
    project_specification_reference: ArtifactReference
    milestones: list[MilestoneDefinition] = Field(min_length=1)

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "MilestonePlan.validate_plan",
            "required_rules": [
                "approved specification/reference identity and canonical digest binding",
                "milestone-local requirement, task, and verification coverage",
                "mandatory gate, role independence, workspace ownership, and dependency "
                "DAG validation",
            ],
        }
        return schema

    @model_validator(mode="after")
    def validate_plan(self) -> Self:
        specification = self.project_specification
        if (
            specification is None
            or specification.status.value != "approved"
            or specification.approval is None
        ):
            raise ValueError("approved project specification is required")
        if self.project_specification_reference.artifact_id != specification.identity.project_id:
            raise ValueError("specification reference ID does not match")
        if self.project_specification_reference.sha256 != specification.approval_digest():
            raise ValueError("specification reference digest does not match")

        milestone_ids = [milestone.milestone_id for milestone in self.milestones]
        if len(milestone_ids) != len(set(milestone_ids)):
            raise ValueError("duplicate milestone ID")
        if [milestone.ordinal for milestone in self.milestones] != list(
            range(1, len(self.milestones) + 1)
        ):
            raise ValueError("milestone ordinals must be contiguous and ordered")

        tasks = [task for milestone in self.milestones for task in milestone.tasks]
        task_ids = [task.task_id for task in tasks]
        if len(task_ids) != len(set(task_ids)):
            raise ValueError("duplicate task ID")
        task_by_id = {task.task_id: task for task in tasks}
        task_milestone = {
            task.task_id: milestone.ordinal
            for milestone in self.milestones
            for task in milestone.tasks
        }
        verification_ids = [
            step.verification_id
            for milestone in self.milestones
            for step in milestone.verification_steps
        ]
        if len(verification_ids) != len(set(verification_ids)):
            raise ValueError("duplicate verification ID")
        if len({task.workspace.locator for task in tasks}) != len(tasks):
            raise ValueError("duplicate workspace ownership")

        approved_requirement_ids = {
            requirement.requirement_id
            for requirement in [
                *specification.functional_requirements,
                *specification.non_functional_requirements,
            ]
        }
        declared_requirement_ids = {
            requirement_id
            for milestone in self.milestones
            for requirement_id in milestone.requirement_ids
        }
        for milestone in self.milestones:
            milestone_requirement_ids = set(milestone.requirement_ids)
            if len(milestone.requirement_ids) != len(milestone_requirement_ids):
                raise ValueError("duplicate milestone requirement IDs")
            unknown_milestone_requirements = sorted(
                milestone_requirement_ids - approved_requirement_ids
            )
            if unknown_milestone_requirements:
                raise ValueError(
                    f"unknown milestone requirement IDs: {unknown_milestone_requirements}"
                )
            local_task_ids = {task.task_id for task in milestone.tasks}
            local_task_requirement_ids = {
                requirement_id
                for task in milestone.tasks
                for requirement_id in task.requirement_ids
            }
            unknown_task_requirements = sorted(
                local_task_requirement_ids - approved_requirement_ids
            )
            if unknown_task_requirements:
                raise ValueError(f"unknown requirement IDs: {unknown_task_requirements}")
            task_requirements_outside_milestone = sorted(
                local_task_requirement_ids - milestone_requirement_ids
            )
            if task_requirements_outside_milestone:
                raise ValueError(
                    f"task requirements outside milestone: {task_requirements_outside_milestone}"
                )
            missing_local_task_coverage = sorted(
                milestone_requirement_ids - local_task_requirement_ids
            )
            if missing_local_task_coverage:
                raise ValueError(f"missing task coverage: {missing_local_task_coverage}")
            gate_kinds = {step.kind for step in milestone.verification_steps}
            for kind in TaskKind.required_gate_kinds():
                if kind not in gate_kinds:
                    raise ValueError(f"missing mandatory gate: {kind.value}")
            for step in milestone.verification_steps:
                unknown_producers = sorted(set(step.producer_task_ids) - set(task_by_id))
                if unknown_producers:
                    raise ValueError(f"unknown verification producer task IDs: {unknown_producers}")
                nonlocal_producers = sorted(set(step.producer_task_ids) - local_task_ids)
                if nonlocal_producers:
                    raise ValueError(
                        "verification producers must reference local milestone task IDs: "
                        f"{nonlocal_producers}"
                    )
                producer_ids = set(step.producer_task_ids)
                producer_instances = {task_by_id[item].owner_instance_id for item in producer_ids}
                if step.reviewer_instance_id in producer_instances:
                    raise ValueError("reviewer identity must be independent from producing author")
            local_verified_requirement_ids = {
                requirement_id
                for step in milestone.verification_steps
                for task_id in step.producer_task_ids
                for requirement_id in task_by_id[task_id].requirement_ids
            }
            missing_local_verification_coverage = sorted(
                milestone_requirement_ids - local_verified_requirement_ids
            )
            if missing_local_verification_coverage:
                raise ValueError(
                    f"missing verification coverage: {missing_local_verification_coverage}"
                )

        missing_milestone_coverage = sorted(approved_requirement_ids - declared_requirement_ids)
        if missing_milestone_coverage:
            raise ValueError(f"missing milestone coverage: {missing_milestone_coverage}")

        for task in tasks:
            unknown_dependencies = sorted(set(task.dependency_task_ids) - set(task_by_id))
            if unknown_dependencies:
                raise ValueError(f"unknown dependency task IDs: {unknown_dependencies}")
            if task.task_id in task.dependency_task_ids:
                raise ValueError(f"self dependency: {task.task_id}")

        self._validate_acyclic(task_by_id)
        for task in tasks:
            later_dependencies = sorted(
                dependency_id
                for dependency_id in task.dependency_task_ids
                if task_milestone[dependency_id] > task_milestone[task.task_id]
            )
            if later_dependencies:
                raise ValueError(f"later milestone dependencies: {later_dependencies}")

        for milestone in self.milestones:
            for step in milestone.verification_steps:
                if step.kind not in {TaskKind.CODE_REVIEW, TaskKind.INDEPENDENT_AUDIT}:
                    continue
                for task_id in step.producer_task_ids:
                    producer = task_by_id[task_id]
                    if (
                        producer.kind is TaskKind.IMPLEMENTATION
                        and producer.owner_instance_id == step.reviewer_instance_id
                    ):
                        raise ValueError("reviewer cannot own implementation they assure")
        return self

    @staticmethod
    def _validate_acyclic(tasks: dict[str, PlannedTask]) -> None:
        colors = {task_id: 0 for task_id in tasks}
        for root in sorted(tasks):
            if colors[root] != 0:
                continue
            colors[root] = 1
            stack: list[tuple[str, Iterator[str]]] = [
                (root, iter(sorted(tasks[root].dependency_task_ids)))
            ]
            while stack:
                task_id, iterator = stack[-1]
                try:
                    dependency_id = next(iterator)
                except StopIteration:
                    colors[task_id] = 2
                    stack.pop()
                    continue
                if colors[dependency_id] == 1:
                    raise ValueError(f"cycle detected: {dependency_id}")
                if colors[dependency_id] == 0:
                    colors[dependency_id] = 1
                    stack.append(
                        (dependency_id, iter(sorted(tasks[dependency_id].dependency_task_ids)))
                    )
