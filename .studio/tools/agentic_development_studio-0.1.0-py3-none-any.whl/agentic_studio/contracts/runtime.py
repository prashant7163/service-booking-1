from __future__ import annotations

from collections.abc import Mapping
from enum import StrEnum
from typing import Any, Self

from pydantic import AwareDatetime, Field, model_validator

from .planning import ArtifactReference, _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel

_SENSITIVE_KEY_FRAGMENTS = (
    "api_key",
    "authorization",
    "credential",
    "password",
    "private_key",
    "secret",
    "token",
)


def _contains_sensitive_key(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            if any(fragment in normalized for fragment in _SENSITIVE_KEY_FRAGMENTS):
                return True
            if _contains_sensitive_key(item):
                return True
    elif isinstance(value, (list, tuple)):
        return any(_contains_sensitive_key(item) for item in value)
    return False


class RunRecord(_ImmutableContractModel):
    project_id: StableId
    run_id: StableId
    selected_runtime: str = Field(min_length=1, max_length=120)
    current_phase: str = Field(min_length=1, max_length=120)
    active_milestone_id: StableId | None
    current_source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    active_references: list[ArtifactReference]
    task_states: dict[StableId, str]
    retry_counters: dict[StableId, int]
    provider_trace_ids: dict[str, str]
    last_event_sequence: int = Field(ge=0)
    created_at: AwareDatetime
    updated_at: AwareDatetime

    @model_validator(mode="after")
    def reject_secret_material(self) -> Self:
        if _contains_sensitive_key(self.model_extra or {}) or _contains_sensitive_key(
            self.provider_trace_ids
        ):
            raise ValueError("run record cannot persist secret material")
        if any(value < 0 for value in self.retry_counters.values()):
            raise ValueError("retry counters cannot be negative")
        return self


class Event(_ImmutableContractModel):
    sequence: int = Field(ge=1)
    event_id: StableId
    occurred_at: AwareDatetime
    project_id: StableId
    run_id: StableId
    session_id: StableId | None
    milestone_id: StableId | None
    task_id: StableId | None
    attempt_number: int | None = Field(default=None, ge=1)
    agent_instance_id: StableId | None
    actor_role: str = Field(min_length=1, max_length=120)
    event_type: str = Field(pattern=r"^[a-z][a-z0-9_]*(?:\.[a-z0-9_]+)+$")
    adapter_name: str = Field(min_length=1, max_length=120)
    trace_correlation_id: StableId
    payload: dict[str, Any]
    previous_hash: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    event_hash: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_redacted_payload(self) -> Self:
        if _contains_sensitive_key(self.payload):
            raise ValueError("event payload must be redacted before persistence")
        return self


class LeaseState(StrEnum):
    ACTIVE = "active"
    EXPIRED = "expired"
    RELEASED = "released"
    REVOKED = "revoked"


class ResumeSafety(StrEnum):
    SAFE = "safe"
    CONDITIONAL = "conditional"
    INVALID = "invalid"


class Session(_ImmutableContractModel):
    session_id: StableId
    project_id: StableId
    run_id: StableId
    started_at: AwareDatetime
    ended_at: AwareDatetime | None
    predecessor_session_id: StableId | None
    predecessor_checkpoint_id: StableId | None
    owning_runtime: str = Field(min_length=1, max_length=120)
    lease_references: list[ArtifactReference]
    initial_context_snapshot_reference: ArtifactReference | None
    terminal_reason: str | None = Field(default=None, min_length=1, max_length=500)
    final_safe_resume_marker_reference: ArtifactReference | None

    @model_validator(mode="after")
    def validate_boundary(self) -> Self:
        if self.ended_at is not None and self.ended_at < self.started_at:
            raise ValueError("session end cannot precede start")
        if (self.predecessor_session_id is None) != (self.predecessor_checkpoint_id is None):
            raise ValueError("resumed session requires predecessor session and checkpoint")
        if self.ended_at is None and self.terminal_reason is not None:
            raise ValueError("active session cannot have a terminal reason")
        return self


class WorkerLease(_ImmutableContractModel):
    lease_id: StableId
    task_id: StableId
    attempt_number: int = Field(ge=1)
    agent_instance_id: StableId
    agent_envelope_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    worker_id: StableId
    role: str = Field(min_length=1, max_length=120)
    specialization_id: StableId
    workspace: str = Field(min_length=1, max_length=500)
    claimed_at: AwareDatetime
    heartbeat_deadline: AwareDatetime
    last_heartbeat_at: AwareDatetime
    generation: int = Field(ge=1)
    state: LeaseState
    handoff_reference: ArtifactReference | None
    safe_resume_marker_reference: ArtifactReference | None

    @model_validator(mode="after")
    def validate_lease(self) -> Self:
        if not _is_safe_repo_locator(self.workspace):
            raise ValueError("lease workspace must be repository-relative")
        if self.heartbeat_deadline <= self.claimed_at:
            raise ValueError("heartbeat deadline must follow claim time")
        if not self.claimed_at <= self.last_heartbeat_at <= self.heartbeat_deadline:
            raise ValueError("last heartbeat must fall inside the lease window")
        if self.state is LeaseState.RELEASED and (
            self.handoff_reference is None or self.safe_resume_marker_reference is None
        ):
            raise ValueError("released lease requires durable handoff and safe marker")
        return self


class Checkpoint(_ImmutableContractModel):
    checkpoint_id: StableId
    project_id: StableId
    run_id: StableId
    task_id: StableId | None
    journal_sequence: int = Field(ge=0)
    previous_checkpoint_hash: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    checkpoint_hash: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    worktree_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    contract_version: str = Field(min_length=1, max_length=80)
    lease_generation: int | None = Field(default=None, ge=1)
    artifact_references: list[ArtifactReference]
    current_action: str = Field(min_length=1, max_length=500)
    next_operation: str = Field(min_length=1, max_length=500)
    completed_work: list[str]
    pending_work: list[str]
    idempotency_outcomes: dict[str, str]
    created_at: AwareDatetime

    @model_validator(mode="after")
    def reject_secret_material(self) -> Self:
        if _contains_sensitive_key(self.idempotency_outcomes) or _contains_sensitive_key(
            self.model_extra or {}
        ):
            raise ValueError("checkpoint cannot persist secret material")
        return self


class ResumeMarker(_ImmutableContractModel):
    marker_id: StableId
    checkpoint_reference: ArtifactReference | None
    classification: ResumeSafety
    reason_code: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    explanation: str = Field(min_length=1, max_length=500)
    completed_work: list[str]
    remaining_work: list[str]
    next_operation: str = Field(min_length=1, max_length=500)
    user_confirmation_required: bool
    created_at: AwareDatetime

    @model_validator(mode="after")
    def validate_resume_claim(self) -> Self:
        if self.classification is ResumeSafety.SAFE and self.checkpoint_reference is None:
            raise ValueError("safe marker requires a validated checkpoint reference")
        if self.classification is ResumeSafety.SAFE and self.user_confirmation_required:
            raise ValueError("safe marker cannot require confirmation")
        return self
