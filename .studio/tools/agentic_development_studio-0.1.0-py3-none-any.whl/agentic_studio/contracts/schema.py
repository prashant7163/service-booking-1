from __future__ import annotations

import argparse
import json
import os
import secrets
import stat
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path
from types import MappingProxyType

from .approval import Approval
from .assurance import (
    BuildStatus,
    CodeReview,
    IndependentAudit,
    MilestoneReview,
    QualityEngineeringReport,
)
from .base import ContractModel
from .config import StudioConfig
from .context import ContextHit, ContextPack, ContextPackManifest, ContextQuery, ContextSnapshot
from .control_plane import RunImportManifest
from .governance import (
    PromptTemplate,
    QualityGatePolicy,
    RoleCapabilityRegistry,
    RoleCatalog,
    StandardsException,
    StandardsProfile,
    WorkflowPolicy,
)
from .instances import AgentInstance, SpawnProposal
from .operations import (
    ExternalCapability,
    IncidentRecord,
    OperatorControl,
    PreflightResult,
    ProjectProvenance,
    ThreatModel,
    UpgradeAssessment,
)
from .planning import MilestonePlan
from .progress import (
    BlastRadius,
    BlastRadiusExemption,
    ChangeIntent,
    ImplementationTracker,
    MilestoneProgress,
)
from .project_spec import ProjectSpecification
from .readiness import ContractSnapshot, MilestoneReadiness
from .runtime import Checkpoint, Event, ResumeMarker, RunRecord, Session, WorkerLease
from .security import OutboundManifest, SensitiveFinding
from .skills import RoleSkillProfile, SkillManifest, SkillRegistry, SpecializationBundle
from .workflow import Handoff, Task, TaskResult

SCHEMA_DRAFT = "https://json-schema.org/draft/2020-12/schema"
SCHEMA_BASE = "https://schemas.agentic-studio.local/v1"
SchemaRegistry = Mapping[str, type[ContractModel]]
SCHEMA_REGISTRY: SchemaRegistry = MappingProxyType(
    {
        "approval": Approval,
        "control-plane": RunImportManifest,
        "project-spec": ProjectSpecification,
        "milestone-plan": MilestonePlan,
        "agent-instance": AgentInstance,
        "spawn-proposal": SpawnProposal,
        "milestone-readiness": MilestoneReadiness,
        "contract-snapshot": ContractSnapshot,
        "task": Task,
        "handoff": Handoff,
        "task-result": TaskResult,
        "change-intent": ChangeIntent,
        "blast-radius": BlastRadius,
        "blast-radius-exemption": BlastRadiusExemption,
        "implementation-tracker": ImplementationTracker,
        "milestone-progress": MilestoneProgress,
        "code-review": CodeReview,
        "build-status": BuildStatus,
        "quality-engineering-report": QualityEngineeringReport,
        "independent-audit": IndependentAudit,
        "milestone-review": MilestoneReview,
        "run-record": RunRecord,
        "event": Event,
        "studio-config": StudioConfig,
        "session": Session,
        "worker-lease": WorkerLease,
        "checkpoint": Checkpoint,
        "resume-marker": ResumeMarker,
        "context-query": ContextQuery,
        "context-hit": ContextHit,
        "context-snapshot": ContextSnapshot,
        "context-pack-manifest": ContextPackManifest,
        "context-pack": ContextPack,
        "sensitive-finding": SensitiveFinding,
        "outbound-manifest": OutboundManifest,
        "standards-profile": StandardsProfile,
        "role-catalog": RoleCatalog,
        "role-capability-registry": RoleCapabilityRegistry,
        "workflow-policy": WorkflowPolicy,
        "quality-gate-policy": QualityGatePolicy,
        "prompt-template": PromptTemplate,
        "skill-manifest": SkillManifest,
        "role-skill-profile": RoleSkillProfile,
        "skill-registry": SkillRegistry,
        "preflight-result": PreflightResult,
        "operator-control": OperatorControl,
        "external-capability": ExternalCapability,
        "threat-model": ThreatModel,
        "incident-record": IncidentRecord,
        "standards-exception": StandardsException,
        "specialization-bundle": SpecializationBundle,
        "project-provenance": ProjectProvenance,
        "upgrade-assessment": UpgradeAssessment,
    }
)


def _schema_filename(name: str) -> str:
    if (
        not name
        or name in {".", ".."}
        or "/" in name
        or "\\" in name
        or "\x00" in name
        or Path(name).name != name
    ):
        raise ValueError(f"unsafe schema registry name: {name!r}")
    filename = f"{name}.schema.json"
    if Path(filename).name != filename:
        raise ValueError(f"unsafe schema registry name: {name!r}")
    return filename


def _render_schema(name: str, model: type[ContractModel]) -> str:
    _schema_filename(name)
    schema = model.model_json_schema(mode="validation", ref_template="#/$defs/{model}")
    schema["$schema"] = SCHEMA_DRAFT
    schema["$id"] = f"{SCHEMA_BASE}/{name}.schema.json"
    return json.dumps(schema, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def render_schema(name: str) -> str:
    return _render_schema(name, SCHEMA_REGISTRY[name])


def expected_schemas(registry: SchemaRegistry | None = None) -> dict[str, str]:
    active_registry = SCHEMA_REGISTRY if registry is None else registry
    return {
        _schema_filename(name): _render_schema(name, model)
        for name, model in active_registry.items()
    }


def _same_file(left: os.stat_result, right: os.stat_result) -> bool:
    return left.st_dev == right.st_dev and left.st_ino == right.st_ino


def _directory_open_flags() -> int:
    if not hasattr(os, "O_DIRECTORY") or not hasattr(os, "O_NOFOLLOW"):
        raise OSError("secure schema directory operations are unsupported on this platform")
    return os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW


def _open_output_dir(output_dir: Path, *, create: bool) -> int:
    if output_dir.is_absolute():
        descriptor = os.open("/", _directory_open_flags())
        components = output_dir.parts[1:]
    else:
        descriptor = os.open(".", _directory_open_flags())
        components = output_dir.parts
    try:
        for component in components:
            if component in {"", ".", ".."}:
                raise OSError(f"unsafe schema output component: {component!r}")
            try:
                next_descriptor = os.open(component, _directory_open_flags(), dir_fd=descriptor)
            except FileNotFoundError:
                if not create:
                    os.close(descriptor)
                    return -1
                os.mkdir(component, dir_fd=descriptor)
                next_descriptor = os.open(component, _directory_open_flags(), dir_fd=descriptor)
            if not stat.S_ISDIR(os.fstat(next_descriptor).st_mode):
                os.close(next_descriptor)
                raise NotADirectoryError(component)
            os.close(descriptor)
            descriptor = next_descriptor
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _assert_output_dir_identity(output_dir: Path, descriptor: int) -> None:
    current_descriptor = _open_output_dir(output_dir, create=False)
    try:
        if current_descriptor == -1 or not _same_file(
            os.fstat(current_descriptor), os.fstat(descriptor)
        ):
            raise OSError(f"schema output directory changed during operation: {output_dir}")
    finally:
        if current_descriptor != -1:
            os.close(current_descriptor)


def _target_path(output_dir: Path, filename: str) -> Path:
    target = output_dir / filename
    if target.parent != output_dir or target.name != filename:
        raise ValueError(f"schema target escapes output directory: {filename!r}")
    return target


def _open_temporary_file(directory_fd: int, filename: str) -> tuple[int, str]:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    for _ in range(16):
        temporary_name = f".{filename}.{secrets.token_hex(16)}.tmp"
        try:
            return os.open(temporary_name, flags, 0o600, dir_fd=directory_fd), temporary_name
        except FileExistsError:
            continue
    raise FileExistsError(f"unable to allocate temporary schema file for {filename}")


def _atomic_write(directory_fd: int, filename: str, content: str) -> None:
    descriptor, temporary_name = _open_temporary_file(directory_fd, filename)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as file:
            descriptor = -1
            file.write(content)
            file.flush()
            os.fsync(file.fileno())
        os.replace(
            temporary_name,
            filename,
            src_dir_fd=directory_fd,
            dst_dir_fd=directory_fd,
        )
    finally:
        if descriptor != -1:
            os.close(descriptor)
        try:
            os.unlink(temporary_name, dir_fd=directory_fd)
        except FileNotFoundError:
            pass


def generate_schemas(
    output_dir: Path, *, registry: SchemaRegistry | None = None
) -> tuple[Path, ...]:
    directory_fd = _open_output_dir(output_dir, create=True)
    written: list[Path] = []
    try:
        for filename, content in expected_schemas(registry).items():
            target = _target_path(output_dir, filename)
            _atomic_write(directory_fd, target.name, content)
            written.append(target)
        _assert_output_dir_identity(output_dir, directory_fd)
    finally:
        os.close(directory_fd)
    return tuple(written)


def stale_schemas(output_dir: Path) -> tuple[str, ...]:
    expected = expected_schemas()
    findings: list[str] = []
    try:
        directory_fd = _open_output_dir(output_dir, create=False)
    except OSError:
        return ("unreadable:output_dir",)
    if directory_fd == -1:
        return tuple(sorted(f"missing:{filename}" for filename in expected))
    try:
        with os.scandir(directory_fd) as entries:
            actual_names = {entry.name for entry in entries if entry.name.endswith(".schema.json")}
        for filename, content in expected.items():
            try:
                metadata = os.stat(filename, dir_fd=directory_fd, follow_symlinks=False)
            except FileNotFoundError:
                findings.append(f"missing:{filename}")
                continue
            if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
                findings.append(f"unreadable:{filename}")
                continue
            descriptor = -1
            try:
                descriptor = os.open(
                    filename,
                    os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0),
                    dir_fd=directory_fd,
                )
                with os.fdopen(descriptor, encoding="utf-8") as file:
                    descriptor = -1
                    if not _same_file(metadata, os.fstat(file.fileno())) or file.read() != content:
                        findings.append(f"modified:{filename}")
            except (OSError, UnicodeError):
                findings.append(f"unreadable:{filename}")
            finally:
                if descriptor != -1:
                    os.close(descriptor)
        _assert_output_dir_identity(output_dir, directory_fd)
    except OSError:
        return ("unreadable:output_dir",)
    finally:
        os.close(directory_fd)
    for filename in actual_names - set(expected):
        findings.append(f"unexpected:{filename}")
    return tuple(sorted(findings))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="studio-contracts")
    parser.add_argument("command", choices=("generate", "check"))
    parser.add_argument("--output-dir", type=Path, default=Path("shared/contracts"))
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    output_dir: Path = arguments.output_dir
    if arguments.command == "generate":
        try:
            for path in generate_schemas(output_dir):
                print(path.as_posix())
        except OSError as error:
            print(f"unable to generate schemas: {error}", file=sys.stderr)
            return 1
        return 0

    findings = stale_schemas(output_dir)
    if findings:
        for finding in findings:
            print(finding, file=sys.stderr)
        return 1
    print("schemas are current")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
