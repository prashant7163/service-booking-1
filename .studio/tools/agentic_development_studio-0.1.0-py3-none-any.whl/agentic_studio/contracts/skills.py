from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from .planning import ArtifactReference
from .project_spec import StableId, _ImmutableContractModel


class SkillTrustStatus(StrEnum):
    REFERENCE_ONLY = "reference_only"
    UNTRUSTED_CANDIDATE = "untrusted_candidate"
    TRUSTED_ACTIVE = "trusted_active"
    REVOKED = "revoked"


class SkillManifest(_ImmutableContractModel):
    skill_id: StableId
    version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    purpose: str = Field(min_length=1, max_length=500)
    triggers: list[str] = Field(min_length=1)
    inputs: list[str]
    outputs: list[str] = Field(min_length=1)
    compatible_roles: list[StableId] = Field(min_length=1)
    tool_dependencies: list[str]
    data_dependencies: list[str]
    permissions: list[str]
    prohibited_uses: list[str]
    fallback: str = Field(min_length=1, max_length=500)
    content_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    provenance: str = Field(min_length=1, max_length=500)
    license: str = Field(min_length=1, max_length=120)
    trust_status: SkillTrustStatus
    evaluation_references: list[ArtifactReference]


class RoleSkillProfile(_ImmutableContractModel):
    profile_id: StableId
    role_id: StableId
    required_skill_ids: list[StableId]
    optional_skill_ids: list[StableId]
    prohibited_skill_ids: list[StableId]
    fallback: str = Field(min_length=1, max_length=500)


class SkillRegistry(_ImmutableContractModel):
    registry_id: StableId
    skills: list[SkillManifest]
    profiles: list[RoleSkillProfile]

    @model_validator(mode="after")
    def validate_registry(self) -> Self:
        skill_ids = [skill.skill_id for skill in self.skills]
        if len(skill_ids) != len(set(skill_ids)):
            raise ValueError("duplicate skill ID")
        known = set(skill_ids)
        for profile in self.profiles:
            referenced = {
                *profile.required_skill_ids,
                *profile.optional_skill_ids,
                *profile.prohibited_skill_ids,
            }
            if not referenced.issubset(known):
                raise ValueError("role skill profile references an unknown skill")
        return self


class SpecializationBundle(_ImmutableContractModel):
    bundle_id: StableId
    domain: str = Field(min_length=1, max_length=200)
    role_facets: dict[StableId, list[StableId]]
    required_assurance_roles: list[StableId]
    fallback: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def validate_coverage(self) -> Self:
        if not set(self.required_assurance_roles).issubset(self.role_facets):
            raise ValueError("specialization bundle lacks required assurance facets")
        return self
