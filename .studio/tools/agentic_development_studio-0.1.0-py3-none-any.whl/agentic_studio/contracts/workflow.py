from __future__ import annotations

from enum import StrEnum
from typing import Any, Self

from pydantic import AwareDatetime, Field, model_validator

from .planning import ArtifactReference, _is_safe_repo_locator
from .project_spec import StableId, _ImmutableContractModel, _ImmutableStudioModel


class ChangeClass(StrEnum):
    CODE_PRODUCING = "code_producing"
    EXECUTABLE_OR_CONFIGURATION = "executable_or_configuration"
    SECURITY_SENSITIVE = "security_sensitive"
    DOCUMENTATION_ONLY = "documentation_only"


class TaskLifecycle(StrEnum):
    PLANNED = "planned"
    READINESS_PENDING = "readiness_pending"
    READY = "ready"
    CLAIMED = "claimed"
    RUNNING = "running"
    WAITING = "waiting"
    MATERIAL_DEVIATION = "material_deviation"
    BLOCKED = "blocked"
    IMPLEMENTATION_COMPLETE = "implementation_complete"
    CODE_REVIEW = "code_review"
    BUILD_VERIFICATION = "build_verification"
    QUALITY_REVIEW = "quality_review"
    INDEPENDENT_AUDIT = "independent_audit"
    AUDIT_TRIAGE = "audit_triage"
    DOCUMENTATION_REVIEW = "documentation_review"
    AWAITING_USER_APPROVAL = "awaiting_user_approval"
    APPROVED = "approved"
    REVISION_REQUIRED = "revision_required"
    FAILED = "failed"
    INTERRUPTED = "interrupted"
    CANCELLED = "cancelled"


class ResultOutcome(StrEnum):
    SUCCESS = "success"
    FAILED = "failed"
    BLOCKED = "blocked"
    INTERRUPTED = "interrupted"


class ErrorRecord(_ImmutableStudioModel):
    code: str = Field(min_length=1, max_length=120)
    message: str = Field(min_length=1, max_length=500)
    retryable: bool = False
    evidence_references: list[ArtifactReference] = Field(default_factory=list)


class Task(_ImmutableContractModel):
    task_id: StableId
    project_id: StableId
    run_id: StableId
    milestone_id: StableId
    assigned_agent_instance_id: StableId
    agent_envelope_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    objective: str = Field(min_length=1, max_length=500)
    owning_role: str = Field(min_length=1, max_length=120)
    change_class: ChangeClass
    author_id: StableId
    dependency_ids: list[StableId]
    ready_dependency_ids: list[StableId]
    requirement_ids: list[StableId]
    acceptance_criterion_ids: list[StableId]
    milestone_readiness: ArtifactReference
    contract_snapshot: ArtifactReference
    work_package: ArtifactReference
    milestone_progress: ArtifactReference
    task_progress: ArtifactReference | None = None
    change_intent_references: list[ArtifactReference]
    declared_inputs: list[ArtifactReference]
    required_outputs: list[str] = Field(min_length=1)
    allowed_paths: list[str] = Field(min_length=1)
    allowed_tools: list[str]
    network_policy: str = Field(min_length=1, max_length=120)
    workspace: str = Field(min_length=1, max_length=500)
    risk: str = Field(min_length=1, max_length=80)
    required_approval_ids: list[StableId]
    verification_commands: list[str] = Field(default_factory=list)
    gate_chain: list[str] = Field(min_length=1)
    reviewer_must_differ: bool = True
    auditor_must_differ: bool = True
    remediation_owner_role: str = Field(min_length=1, max_length=120)
    downstream_gates: list[str]
    max_attempts: int = Field(ge=1)
    attempt_number: int = Field(ge=1)
    lifecycle: TaskLifecycle
    created_at: AwareDatetime | None = None

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        schema = super().model_json_schema(*args, **kwargs)
        schema["x-agentic-studio-runtime-validation"] = {
            "canonical_validator": "Task.validate_execution_envelope",
            "required_rules": [
                "all declared dependencies are ready before task release",
                "non-documentation changes preserve mandatory gate order",
                "paths remain repository-relative and retry budget is not exhausted",
            ],
        }
        return schema

    @model_validator(mode="after")
    def validate_execution_envelope(self) -> Self:
        if not set(self.dependency_ids).issubset(self.ready_dependency_ids):
            raise ValueError("dependencies are not ready")
        if any(not _is_safe_repo_locator(path) for path in (*self.allowed_paths, self.workspace)):
            raise ValueError("allowed paths and workspace must be repository-relative")
        if self.attempt_number > self.max_attempts:
            raise ValueError("attempt exceeds retry policy")
        required = (
            "code_review",
            "build_verification",
            "quality_review",
            "independent_audit",
        )
        if self.change_class is not ChangeClass.DOCUMENTATION_ONLY:
            positions = [
                self.gate_chain.index(gate) for gate in required if gate in self.gate_chain
            ]
            if len(positions) != len(required) or positions != sorted(positions):
                raise ValueError("required gate chain is incomplete or out of order")
        if len(self.allowed_paths) != len(set(self.allowed_paths)):
            raise ValueError("duplicate allowed path")
        return self


class Handoff(_ImmutableContractModel):
    handoff_id: StableId
    task_id: StableId
    agent_instance_id: StableId
    agent_envelope_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    sender_role: str = Field(min_length=1, max_length=120)
    recipient_role: str = Field(min_length=1, max_length=120)
    context_summary: str = Field(min_length=1, max_length=2000)
    context_pack_manifest_id: StableId
    provenance_references: list[ArtifactReference]
    readiness_reference: ArtifactReference
    contract_reference: ArtifactReference
    work_package_reference: ArtifactReference
    progress_reference: ArtifactReference
    current_action: str = Field(min_length=1, max_length=500)
    next_action: str = Field(min_length=1, max_length=500)
    safe_resume_marker_id: StableId
    constraints: list[str]
    acceptance_criteria: list[str]
    allowed_paths: list[str]
    allowed_tools: list[str]
    expected_result_schema: str = Field(min_length=1, max_length=120)
    workspace: str = Field(min_length=1, max_length=500)
    source_revision: str = Field(pattern=r"^[0-9a-f]{40,64}$")
    candidate_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    author_id: StableId
    reviewer_id: StableId | None = None
    applicable_gate: str = Field(min_length=1, max_length=120)
    prior_gate_references: list[ArtifactReference]
    response_destination: str = Field(min_length=1, max_length=120)
    termination_condition: str = Field(min_length=1, max_length=500)
    correlation_ids: list[StableId]

    @model_validator(mode="after")
    def validate_bounded_handoff(self) -> Self:
        forbidden = {
            "conversation_transcript",
            "credentials",
            "tracker_history",
            "prior_conversation",
        }
        extras = set(self.model_extra or {})
        if extras & forbidden:
            raise ValueError("handoff cannot contain transcripts, credentials, or tracker history")
        if any(not _is_safe_repo_locator(path) for path in (*self.allowed_paths, self.workspace)):
            raise ValueError("handoff paths and workspace must be repository-relative")
        if (
            self.recipient_role == "independent-auditor"
            and self.response_destination != "orchestrator"
        ):
            raise ValueError("independent audit handoff must return to orchestrator")
        return self


class TaskResult(_ImmutableContractModel):
    result_id: StableId
    task_id: StableId
    attempt_number: int = Field(ge=1)
    outcome: ResultOutcome
    artifact_references: list[ArtifactReference]
    changed_paths: list[str]
    candidate_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    self_verification: list[str]
    unit_test_evidence: list[ArtifactReference]
    quality_evidence: list[ArtifactReference]
    assumptions: list[str]
    limitations: list[str]
    risks: list[str]
    requested_follow_up: list[str]
    usage: dict[str, int | float | str]
    error: ErrorRecord | None
    change_class: ChangeClass

    @model_validator(mode="after")
    def validate_result_evidence(self) -> Self:
        if any(not _is_safe_repo_locator(path) for path in self.changed_paths):
            raise ValueError("changed paths must be repository-relative")
        if self.outcome is ResultOutcome.SUCCESS and self.change_class in {
            ChangeClass.CODE_PRODUCING,
            ChangeClass.EXECUTABLE_OR_CONFIGURATION,
            ChangeClass.SECURITY_SENSITIVE,
        }:
            if (
                not self.candidate_digest
                or not self.self_verification
                or not self.unit_test_evidence
            ):
                raise ValueError("successful executable result lacks reviewable evidence")
        if self.outcome is ResultOutcome.FAILED and self.error is None:
            raise ValueError("failed result requires error")
        if self.outcome is not ResultOutcome.FAILED and self.error is not None:
            raise ValueError("non-failed result cannot carry an error")
        return self
