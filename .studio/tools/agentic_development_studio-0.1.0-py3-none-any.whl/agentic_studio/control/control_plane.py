from __future__ import annotations

import hashlib
import secrets
from collections.abc import Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from agentic_studio.contracts import (
    Approval,
    ArtifactInput,
    ArtifactKind,
    ArtifactSubmission,
    Checkpoint,
    CommandResult,
    ExternalCapability,
    ImportRun,
    IncidentRecord,
    InitializeRun,
    OperatorControl,
    ResultCode,
    ResumeMarker,
    RunSelection,
    Session,
    StudioConfig,
    TaskLifecycle,
)
from agentic_studio.persistence import (
    ArtifactCorruptionError,
    ArtifactRegistry,
    EventJournal,
    JournalCorruptionError,
    RunStore,
)
from agentic_studio.progress import ProjectionStore, RunProjection

from .governance_ops import GovernanceDenied, GovernanceOperations, RetentionRequest
from .importer import PreparedImport, RunImporter
from .recovery_ops import RecoveryDenied, RecoveryOperations, bounded_items
from .submissions import SubmissionDenied, SubmissionValidator

Clock = Callable[[], datetime]
IdFactory = Callable[[], str]


def _default_id() -> str:
    return secrets.token_hex(12)


class ControlPlaneService:
    def __init__(
        self,
        project_root: Path,
        *,
        clock: Clock | None = None,
        id_factory: IdFactory | None = None,
    ) -> None:
        self.project_root = project_root.resolve(strict=True)
        self.clock = clock or (lambda: datetime.now(UTC))
        self.id_factory = id_factory or _default_id
        self.journal = EventJournal(self.project_root / ".studio/journal/events.jsonl")
        self.projections = ProjectionStore(self.project_root)
        self.runs = RunStore(self.project_root)

    def _config(self) -> StudioConfig:
        path = self.project_root / "studio.yaml"
        try:
            payload = yaml.safe_load(path.read_text(encoding="utf-8"))
            return StudioConfig.model_validate(payload)
        except (OSError, UnicodeError, yaml.YAMLError, ValidationError, TypeError) as error:
            raise ValueError("studio.yaml is missing or invalid") from error

    def event_fields(
        self,
        event_type: str,
        run_id: str,
        *,
        payload: Mapping[str, Any],
        project_id: str | None = None,
        session_id: str | None = None,
        milestone_id: str | None = None,
        task_id: str | None = None,
        attempt_number: int | None = None,
        agent_instance_id: str | None = None,
    ) -> dict[str, Any]:
        configured_project_id = project_id or self._config().project_id
        return {
            "schema_version": "1.0.0",
            "event_id": f"event-{self.id_factory()}",
            "occurred_at": self.clock(),
            "project_id": configured_project_id,
            "run_id": run_id,
            "session_id": session_id,
            "milestone_id": milestone_id,
            "task_id": task_id,
            "attempt_number": attempt_number,
            "agent_instance_id": agent_instance_id,
            "actor_role": "orchestrator-tech-lead",
            "event_type": event_type,
            "adapter_name": "studioctl",
            "trace_correlation_id": f"trace-{self.id_factory()}",
            "payload": dict(payload),
        }

    @staticmethod
    def _state(run: RunProjection) -> dict[str, Any]:
        return run.model_dump(mode="json")

    @staticmethod
    def _error_summary(error: BaseException) -> str:
        first_line = str(error).splitlines()[0].strip()
        return (first_line or type(error).__name__)[:500]

    @staticmethod
    def _next_action(run: RunProjection) -> str:
        if run.import_state == "started":
            return "Resume or abandon the interrupted import."
        return {
            "discovery": "Submit an approved specification.",
            "specification_approved": "Submit an approved milestone plan.",
            "planning": "Submit readiness evidence.",
            "readiness_pending": "Submit readiness evidence.",
            "ready": "Submit an approved task.",
            "running": "Inspect progress and complete the active task.",
            "blocked": "Submit new readiness evidence.",
            "awaiting_user_approval": "Obtain exact user approval.",
            "approved": "Start a new run for additional work.",
            "cancelled": "Initialize or select another run.",
        }[run.phase.value]

    def _result_for_run(
        self,
        run: RunProjection,
        *,
        code: ResultCode = ResultCode.OK,
        summary: str = "Run state loaded from the authoritative journal.",
    ) -> CommandResult:
        return CommandResult(
            code=code,
            summary=summary,
            state=self._state(run),
            next_action=self._next_action(run),
        )

    def _idempotency_result(
        self,
        key: str,
        operation: str,
        payload_digest: str,
        *,
        allow_interrupted_import: bool = False,
    ) -> CommandResult | None:
        matches = []
        for event in self.journal.replay():
            payload = event.model_dump(mode="json")["payload"]
            if payload.get("idempotency_key") == key:
                matches.append((event, payload))
        if not matches:
            return None
        if any(
            payload.get("operation") != operation or payload.get("payload_digest") != payload_digest
            for _, payload in matches
        ):
            return CommandResult(
                code=ResultCode.CONFLICT,
                summary="Idempotency key was already used for a different operation or payload.",
                next_action="Use a new idempotency key for the changed request.",
            )
        run_id = matches[0][0].run_id
        run = self.runs.inspect(run_id)
        if run is None:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary="Recorded run is missing.")
        if allow_interrupted_import and run.import_state == "started":
            return None
        return self._result_for_run(run, summary="Idempotent request already recorded.")

    def status(self, run_id: str | None = None) -> CommandResult:
        try:
            config = self._config()
            projection = self.projections.load_or_rebuild()
            if run_id is not None:
                run = projection.runs.get(run_id)
                if run is None:
                    return CommandResult(
                        code=ResultCode.INVALID_INPUT,
                        summary=f"Unknown run: {run_id}",
                        next_action="List runs and select an existing run.",
                    )
            elif projection.active_run_id is not None:
                run = projection.runs[projection.active_run_id]
            else:
                interrupted = [
                    candidate
                    for candidate in projection.runs.values()
                    if candidate.import_state == "started"
                ]
                if len(interrupted) == 1:
                    return self._result_for_run(
                        interrupted[0],
                        code=ResultCode.POLICY_DENIED,
                        summary="Run import was interrupted before completion.",
                    )
                return CommandResult(
                    code=ResultCode.NOT_INITIALIZED,
                    summary="No active Studio run is initialized or selected.",
                    state={
                        "project_id": config.project_id,
                        "selected_runtime": config.selected_runtime,
                        "active_run_id": None,
                    },
                    next_action="Initialize a new run or import verified pre-native evidence.",
                )
            if run.import_state == "started":
                return self._result_for_run(
                    run,
                    code=ResultCode.POLICY_DENIED,
                    summary="Run import was interrupted before completion.",
                )
            return self._result_for_run(run)
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(
                code=ResultCode.STATE_CORRUPT,
                summary=self._error_summary(error),
                next_action="Preserve the evidence and repair authoritative state.",
            )
        except ValueError as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def initialize_run(self, request: InitializeRun) -> CommandResult:
        try:
            config = self._config()
            repeated = self._idempotency_result(
                request.idempotency_key,
                "run.initialize",
                request.payload_digest,
            )
            if repeated is not None:
                return repeated
            run_id = request.run_id or f"run-{self.id_factory()}"
            projection = self.projections.load_or_rebuild()
            if run_id in projection.runs:
                return CommandResult(
                    code=ResultCode.CONFLICT,
                    summary=f"Run already exists: {run_id}",
                    next_action="Select the existing run or use a new run ID.",
                )
            common = {
                "operation": "run.initialize",
                "idempotency_key": request.idempotency_key,
                "payload_digest": request.payload_digest,
            }
            source_revision = hashlib.sha256(
                (self.project_root / "studio.yaml").read_bytes()
            ).hexdigest()
            initialized = self.event_fields(
                "run.initialized",
                run_id,
                project_id=config.project_id,
                payload={
                    **common,
                    "phase": "discovery",
                    "selected_runtime": request.selected_runtime,
                    "current_source_revision": source_revision,
                },
            )
            selected = self.event_fields(
                "run.selected",
                run_id,
                project_id=config.project_id,
                payload=common,
            )
            self.journal.record_many([initialized, selected])
            try:
                run = self.projections.rebuild().runs[run_id]
            except OSError as error:
                return CommandResult(
                    code=ResultCode.STATE_CORRUPT,
                    summary=f"Run was journaled but its projection could not be saved: {error}",
                    next_action="Run status to rebuild the projection.",
                )
            return self._result_for_run(run, summary="Run initialized and selected.")
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def select_run(self, selection: RunSelection) -> CommandResult:
        try:
            config = self._config()
            repeated = self._idempotency_result(
                selection.idempotency_key,
                "run.select",
                selection.payload_digest,
            )
            if repeated is not None:
                return repeated
            run = self.runs.select(
                selection,
                project_id=config.project_id,
                occurred_at=self.clock(),
                event_id=f"event-{self.id_factory()}",
                trace_correlation_id=f"trace-{self.id_factory()}",
                adapter_name="studioctl",
            )
            return self._result_for_run(run, summary="Run selected.")
        except ValueError as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))
        except JournalCorruptionError as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))

    @staticmethod
    def _import_payload_digest(locator: str, manifest_digest: str) -> str:
        material = f"{locator}\0{manifest_digest}".encode()
        return hashlib.sha256(material).hexdigest()

    def _append_import(self, request: ImportRun, prepared: PreparedImport, digest: str) -> None:
        manifest = prepared.manifest
        common = {
            "operation": "run.import",
            "idempotency_key": request.idempotency_key,
            "payload_digest": digest,
            "manifest_locator": request.file,
            "manifest_digest": prepared.manifest_digest,
            "provenance": "pre_native_import",
        }
        current = self.projections.load_or_rebuild().runs.get(manifest.run_id)
        events: list[dict[str, Any]] = []
        if current is None:
            events.append(
                self.event_fields(
                    "run.import.started",
                    manifest.run_id,
                    project_id=manifest.project_id,
                    payload={
                        **common,
                        "phase": "blocked",
                        "selected_runtime": manifest.selected_runtime,
                        "current_source_revision": manifest.current_source_revision,
                    },
                )
            )
        elif current.import_state != "started":
            raise ValueError(f"Run already exists: {manifest.run_id}")
        for artifact in prepared.artifacts:
            events.append(
                self.event_fields(
                    "artifact.imported",
                    manifest.run_id,
                    project_id=manifest.project_id,
                    payload={**common, "artifact": artifact.model_dump(mode="json")},
                )
            )
        events.extend(
            [
                self.event_fields(
                    "readiness.blocked",
                    manifest.run_id,
                    project_id=manifest.project_id,
                    payload={
                        **common,
                        "artifact_sha256": prepared.readiness.sha256,
                        "reason": "Imported readiness requires revision.",
                    },
                ),
                self.event_fields(
                    "run.imported",
                    manifest.run_id,
                    project_id=manifest.project_id,
                    payload={**common, "phase": "blocked"},
                ),
                self.event_fields(
                    "run.selected",
                    manifest.run_id,
                    project_id=manifest.project_id,
                    payload=common,
                ),
            ]
        )
        self.journal.record_many(events)

    def import_run(self, request: ImportRun) -> CommandResult:
        try:
            config = self._config()
            importer = RunImporter(self.project_root, config.project_id)
            manifest, manifest_digest = importer.load_manifest(request.file)
            digest = self._import_payload_digest(request.file, manifest_digest)
            repeated = self._idempotency_result(
                request.idempotency_key,
                "run.import",
                digest,
                allow_interrupted_import=True,
            )
            if repeated is not None:
                return repeated
            current = self.projections.load_or_rebuild().runs.get(manifest.run_id)
            if current is not None and current.import_state != "started":
                return CommandResult(
                    code=ResultCode.CONFLICT,
                    summary=f"Run already exists: {manifest.run_id}",
                )
            prepared = importer.prepare(manifest, manifest_digest)
            self._append_import(request, prepared, digest)
            try:
                run = self.projections.rebuild().runs[manifest.run_id]
            except OSError as error:
                return CommandResult(
                    code=ResultCode.STATE_CORRUPT,
                    summary=f"Import was journaled but its projection could not be saved: {error}",
                    next_action="Run status to rebuild the projection.",
                )
            return self._result_for_run(run, summary="Verified pre-native evidence imported.")
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def abandon_import(self, run_id: str, *, idempotency_key: str) -> CommandResult:
        digest = hashlib.sha256(run_id.encode("utf-8")).hexdigest()
        try:
            repeated = self._idempotency_result(
                idempotency_key,
                "run.import.abandon",
                digest,
            )
            if repeated is not None:
                return repeated
            run = self.runs.inspect(run_id)
            if run is None or run.import_state != "started":
                return CommandResult(
                    code=ResultCode.POLICY_DENIED,
                    summary="Only an interrupted import can be abandoned.",
                )
            event = self.event_fields(
                "run.import.abandoned",
                run_id,
                payload={
                    "operation": "run.import.abandon",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                },
            )
            self.journal.record(**event)
            abandoned = self.projections.rebuild().runs[run_id]
            return self._result_for_run(abandoned, summary="Interrupted import abandoned.")
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except ValueError as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    @staticmethod
    def _submission_digest(request: ArtifactSubmission, artifact_sha256: str) -> str:
        material = f"{request.payload_digest}\0{artifact_sha256}".encode()
        return hashlib.sha256(material).hexdigest()

    def submit(self, request: ArtifactSubmission) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(
                    code=ResultCode.NOT_INITIALIZED,
                    summary="No active run is selected for artifact submission.",
                    next_action="Initialize or select a run.",
                )
            run = projection.runs[projection.active_run_id]
            if run.import_state == "started":
                return CommandResult(
                    code=ResultCode.POLICY_DENIED,
                    summary="Artifact submission is blocked by an interrupted import.",
                    state=self._state(run),
                    next_action=self._next_action(run),
                )
            self._governance(run).ensure_mutation_allowed()
            registry = ArtifactRegistry(self.project_root, run.run_id)
            registered = registry.register(
                ArtifactInput(
                    kind=request.kind,
                    file=request.file,
                    expected_sha256=request.expected_sha256,
                )
            )
            payload_digest = self._submission_digest(request, registered.sha256)
            repeated = self._idempotency_result(
                request.idempotency_key,
                f"artifact.submit.{request.kind.value}",
                payload_digest,
            )
            if repeated is not None:
                return repeated
            model = registry.load(registered)
            decision = SubmissionValidator(registry, run).decide(request.kind, model)
            payload = {
                "operation": f"artifact.submit.{request.kind.value}",
                "idempotency_key": request.idempotency_key,
                "payload_digest": payload_digest,
                "artifact": registered.model_dump(mode="json"),
            }
            if decision.event_type == "readiness.blocked":
                payload["reason"] = "Submitted readiness requires revision."
            event = self.event_fields(
                decision.event_type,
                run.run_id,
                payload=payload,
                milestone_id=decision.milestone_id,
                task_id=decision.task_id,
                attempt_number=decision.attempt_number,
            )
            self.journal.record(**event)
            try:
                updated = self.projections.rebuild().runs[run.run_id]
            except OSError as error:
                return CommandResult(
                    code=ResultCode.STATE_CORRUPT,
                    summary=f"Artifact was journaled but projection save failed: {error}",
                    next_action="Run status to rebuild the projection.",
                )
            return CommandResult(
                code=ResultCode.OK,
                summary=decision.summary,
                state=self._state(updated),
                next_action=self._next_action(updated),
                details={"artifact": registered.model_dump(mode="json")},
            )
        except GovernanceDenied as error:
            return CommandResult(
                code=ResultCode.POLICY_DENIED,
                summary=self._error_summary(error),
                next_action="Clear the operator control with exact approval.",
            )
        except SubmissionDenied as error:
            return CommandResult(
                code=ResultCode.POLICY_DENIED,
                summary=self._error_summary(error),
                next_action="Correct the evidence binding and resubmit explicitly.",
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def _recovery(self, run: RunProjection) -> RecoveryOperations:
        return RecoveryOperations(
            self.project_root,
            ArtifactRegistry(self.project_root, run.run_id),
            run,
            clock=self.clock,
            id_factory=self.id_factory,
        )

    def _governance(self, run: RunProjection) -> GovernanceOperations:
        return GovernanceOperations(self.project_root, self.journal, run)

    def create_checkpoint(self, *, file: str, idempotency_key: str) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(
                    code=ResultCode.NOT_INITIALIZED,
                    summary="No active run is selected for checkpoint creation.",
                )
            run = projection.runs[projection.active_run_id]
            operation = self._recovery(run)
            registered, loaded = operation.register(ArtifactKind.CHECKPOINT, file)
            if not isinstance(loaded, Checkpoint):
                raise TypeError("checkpoint input did not validate as a checkpoint")
            request = ArtifactSubmission(
                kind=ArtifactKind.CHECKPOINT,
                file=file,
                idempotency_key=idempotency_key,
            )
            payload_digest = self._submission_digest(request, registered.sha256)
            repeated = self._idempotency_result(
                idempotency_key,
                "checkpoint.create",
                payload_digest,
            )
            if repeated is not None:
                return repeated
            checkpoint = operation.save_checkpoint(loaded)
            event = self.event_fields(
                "checkpoint.created",
                run.run_id,
                payload={
                    "operation": "checkpoint.create",
                    "idempotency_key": idempotency_key,
                    "payload_digest": payload_digest,
                    "artifact": registered.model_dump(mode="json"),
                    "checkpoint_id": checkpoint.checkpoint_id,
                    "checkpoint_hash": checkpoint.checkpoint_hash,
                    "current_action": checkpoint.current_action,
                    "next_operation": checkpoint.next_operation,
                },
                task_id=checkpoint.task_id,
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary="Durable checkpoint created.",
                state=self._state(updated),
                next_action=checkpoint.next_operation,
                details={"checkpoint": checkpoint.model_dump(mode="json")},
            )
        except RecoveryDenied as error:
            return CommandResult(
                code=ResultCode.POLICY_DENIED,
                summary=self._error_summary(error),
                next_action="Create a fresh checkpoint from authoritative run state.",
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def inspect_checkpoint(self, run_id: str | None = None) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            selected = run_id or projection.active_run_id
            if selected is None or selected not in projection.runs:
                return CommandResult(
                    code=ResultCode.NOT_INITIALIZED,
                    summary="No run is available for checkpoint inspection.",
                )
            run = projection.runs[selected]
            checkpoint = self._recovery(run).newest_checkpoint()
            return CommandResult(
                code=ResultCode.OK,
                summary="Newest valid checkpoint loaded.",
                state=self._state(run),
                next_action=checkpoint.next_operation,
                details={"checkpoint": checkpoint.model_dump(mode="json")},
            )
        except RecoveryDenied as error:
            return CommandResult(code=ResultCode.POLICY_DENIED, summary=self._error_summary(error))
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def resume(
        self,
        *,
        file: str,
        idempotency_key: str,
        resolution_evidence_ids: tuple[str, ...] = (),
    ) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(
                    code=ResultCode.NOT_INITIALIZED,
                    summary="No active run is selected for recovery.",
                )
            run = projection.runs[projection.active_run_id]
            operation = self._recovery(run)
            registered, loaded = operation.register(ArtifactKind.RESUME_MARKER, file)
            if not isinstance(loaded, ResumeMarker):
                raise TypeError("resume input did not validate as a resume marker")
            request = ArtifactSubmission(
                kind=ArtifactKind.RESUME_MARKER,
                file=file,
                idempotency_key=idempotency_key,
            )
            payload_digest = self._submission_digest(request, registered.sha256)
            repeated = self._idempotency_result(
                idempotency_key,
                "run.resume",
                payload_digest,
            )
            if repeated is not None:
                return repeated
            checkpoint = operation.validate_resume(
                loaded,
                resolution_evidence_ids=resolution_evidence_ids,
            )
            session_id = f"session-{self.id_factory()}"
            predecessor = run.active_session_id
            session = Session(
                schema_version="1.0.0",
                session_id=session_id,
                project_id=run.project_id,
                run_id=run.run_id,
                started_at=self.clock(),
                ended_at=None,
                predecessor_session_id=predecessor,
                predecessor_checkpoint_id=(
                    checkpoint.checkpoint_id if predecessor is not None else None
                ),
                owning_runtime=run.selected_runtime,
                lease_references=[],
                initial_context_snapshot_reference=None,
                terminal_reason=None,
                final_safe_resume_marker_reference=None,
            )
            common = {
                "operation": "run.resume",
                "idempotency_key": idempotency_key,
                "payload_digest": payload_digest,
            }
            events = [
                self.event_fields(
                    "session.started",
                    run.run_id,
                    payload={**common, "session": session.model_dump(mode="json")},
                    session_id=session_id,
                ),
                self.event_fields(
                    "run.resumed",
                    run.run_id,
                    payload={
                        **common,
                        "artifact": registered.model_dump(mode="json"),
                        "classification": loaded.classification.value,
                        "checkpoint_id": checkpoint.checkpoint_id,
                        "current_action": checkpoint.current_action,
                        "next_operation": checkpoint.next_operation,
                        "resolution_evidence_ids": list(resolution_evidence_ids),
                    },
                    session_id=session_id,
                    task_id=checkpoint.task_id,
                ),
            ]
            self.journal.record_many(events)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary="Run resumed from a validated checkpoint.",
                state=self._state(updated),
                next_action=checkpoint.next_operation,
                details={"session": session.model_dump(mode="json")},
            )
        except RecoveryDenied as error:
            return CommandResult(
                code=ResultCode.POLICY_DENIED,
                summary=self._error_summary(error),
                next_action="Satisfy the named recovery condition or create a fresh checkpoint.",
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def retry(
        self,
        *,
        task_id: str,
        idempotency_key: str,
        resolution_evidence_ids: tuple[str, ...] = (),
    ) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            payload = {
                "task_id": task_id,
                "resolution_evidence_ids": list(resolution_evidence_ids),
            }
            digest = RecoveryOperations.request_digest(payload)
            repeated = self._idempotency_result(idempotency_key, "task.retry", digest)
            if repeated is not None:
                return repeated
            operation = self._recovery(run)
            task = operation.task_for_retry(task_id)
            state = run.task_states.get(task_id)
            allowed_states = {
                TaskLifecycle.FAILED.value,
                TaskLifecycle.INTERRUPTED.value,
                TaskLifecycle.BLOCKED.value,
            }
            if state not in allowed_states:
                raise RecoveryDenied("Only failed, interrupted, or blocked tasks can be retried.")
            if state == TaskLifecycle.BLOCKED.value and not resolution_evidence_ids:
                raise RecoveryDenied("Blocked task retry requires named resolution evidence.")
            current_attempt = run.active_attempt_number or task.attempt_number
            if current_attempt >= task.max_attempts:
                raise RecoveryDenied("Task retry budget is exhausted.")
            next_attempt = current_attempt + 1
            retry_count = run.retry_counters.get(task_id, 0) + 1
            event = self.event_fields(
                "task.retry_scheduled",
                run.run_id,
                payload={
                    "operation": "task.retry",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "state": TaskLifecycle.READY.value,
                    "retry_count": retry_count,
                    "resolution_evidence_ids": list(resolution_evidence_ids),
                },
                milestone_id=task.milestone_id,
                task_id=task.task_id,
                attempt_number=next_attempt,
                agent_instance_id=task.assigned_agent_instance_id,
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary="Task retry scheduled with an incremented attempt.",
                state=self._state(updated),
                next_action="Submit the next explicit task attempt.",
                details={"attempt_number": next_attempt, "retry_count": retry_count},
            )
        except RecoveryDenied as error:
            return CommandResult(code=ResultCode.POLICY_DENIED, summary=self._error_summary(error))
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def cancel(
        self,
        *,
        idempotency_key: str,
        force: bool,
        reason: str = "Operator requested cancellation.",
    ) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            mode = "forced" if force else "graceful"
            digest = RecoveryOperations.request_digest({"mode": mode, "reason": reason})
            repeated = self._idempotency_result(idempotency_key, "run.cancel", digest)
            if repeated is not None:
                return repeated
            common = {
                "operation": "run.cancel",
                "idempotency_key": idempotency_key,
                "payload_digest": digest,
                "mode": mode,
                "reason": reason,
            }
            events = []
            if run.active_session_id is not None:
                events.append(
                    self.event_fields(
                        "session.closed",
                        run.run_id,
                        payload=common,
                        session_id=run.active_session_id,
                    )
                )
            events.append(self.event_fields("run.cancelled", run.run_id, payload=common))
            self.journal.record_many(events)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary=f"Run cancelled in {mode} mode.",
                state=self._state(updated),
                next_action=self._next_action(updated),
                details={"mode": mode},
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def close_session(
        self,
        *,
        idempotency_key: str,
        reason: str,
    ) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            if run.active_session_id is None:
                return CommandResult(
                    code=ResultCode.POLICY_DENIED,
                    summary="No active session is available to close.",
                )
            digest = RecoveryOperations.request_digest({"reason": reason})
            repeated = self._idempotency_result(idempotency_key, "session.close", digest)
            if repeated is not None:
                return repeated
            event = self.event_fields(
                "session.closed",
                run.run_id,
                payload={
                    "operation": "session.close",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "reason": reason,
                },
                session_id=run.active_session_id,
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return self._result_for_run(updated, summary="Session closed.")
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def progress(self, *, limit: int = 20, run_id: str | None = None) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            selected = run_id or projection.active_run_id
            if selected is None or selected not in projection.runs:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No run available.")
            run = projection.runs[selected]
            events = [
                event.model_dump(mode="json")
                for event in self.journal.replay()
                if event.run_id == selected
            ]
            return CommandResult(
                code=ResultCode.OK,
                summary="Bounded progress loaded from the authoritative journal.",
                state=self._state(run),
                next_action=run.next_action or self._next_action(run),
                details={"recent_events": bounded_items(events, limit=limit)},
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def apply_control(self, *, file: str, idempotency_key: str) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            registry = ArtifactRegistry(self.project_root, run.run_id)
            registered = registry.register(ArtifactInput(kind=ArtifactKind.CONTROL, file=file))
            control = registry.load(registered)
            if not isinstance(control, OperatorControl):
                raise TypeError("control input did not validate as an operator control")
            request = ArtifactSubmission(
                kind=ArtifactKind.CONTROL,
                file=file,
                idempotency_key=idempotency_key,
            )
            digest = self._submission_digest(request, registered.sha256)
            repeated = self._idempotency_result(idempotency_key, "control.apply", digest)
            if repeated is not None:
                return repeated
            event = self.event_fields(
                "control.applied",
                run.run_id,
                payload={
                    "operation": "control.apply",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "artifact": registered.model_dump(mode="json"),
                    "control": control.model_dump(mode="json"),
                },
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary=f"Operator control applied: {control.action.value}.",
                state=self._state(updated),
                next_action="Inspect or clear the active operator control.",
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def clear_control(
        self,
        *,
        control_id: str,
        approval_file: str | None,
        idempotency_key: str,
    ) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            controls = {
                control.control_id: control
                for control in self._governance(run).active_controls()
            }
            target = controls.get(control_id)
            if target is None:
                raise GovernanceDenied(f"No active operator control exists: {control_id}")
            if approval_file is None:
                raise GovernanceDenied("Operator control clearance requires exact human approval.")
            registry = ArtifactRegistry(self.project_root, run.run_id)
            registered = registry.register(
                ArtifactInput(kind=ArtifactKind.APPROVAL, file=approval_file)
            )
            approval = registry.load(registered)
            if not isinstance(approval, Approval):
                raise TypeError("clearance input did not validate as an approval")
            if (
                approval.decision.value != "approved"
                or approval.subject_type != "operator_control_clearance"
                or approval.subject_id != control_id
                or approval.subject_digest != target.sha256_digest()
            ):
                raise GovernanceDenied("Operator control clearance requires exact human approval.")
            digest = RecoveryOperations.request_digest(
                {
                    "control_id": control_id,
                    "approval_sha256": registered.sha256,
                }
            )
            repeated = self._idempotency_result(idempotency_key, "control.clear", digest)
            if repeated is not None:
                return repeated
            event = self.event_fields(
                "control.cleared",
                run.run_id,
                payload={
                    "operation": "control.clear",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "control_id": control_id,
                    "artifact": registered.model_dump(mode="json"),
                },
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary="Operator control cleared with exact approval.",
                state=self._state(updated),
                next_action=self._next_action(updated),
            )
        except GovernanceDenied as error:
            return CommandResult(
                code=ResultCode.POLICY_DENIED,
                summary=self._error_summary(error),
                next_action="Provide exact human approval for the named control.",
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def inspect_controls(self) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            controls = self._governance(run).active_controls()
            return CommandResult(
                code=ResultCode.OK,
                summary="Active operator controls loaded.",
                state=self._state(run),
                next_action=(
                    "Clear the operator control with exact approval."
                    if controls
                    else self._next_action(run)
                ),
                details={
                    "controls": [control.model_dump(mode="json") for control in controls]
                },
            )
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def apply_retention(self, *, file: str, idempotency_key: str) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            governance = self._governance(run)
            governance.ensure_mutation_allowed()
            registry = ArtifactRegistry(self.project_root, run.run_id)
            registered = registry.register(
                ArtifactInput(kind=ArtifactKind.SUPPORTING_EVIDENCE, file=file)
            )
            loaded = registry.load(registered)
            request = RetentionRequest.model_validate(loaded.model_dump(mode="json"))
            digest = RecoveryOperations.request_digest(
                {
                    "request": request.model_dump(mode="json"),
                    "artifact_sha256": registered.sha256,
                }
            )
            repeated = self._idempotency_result(idempotency_key, "retention.apply", digest)
            if repeated is not None:
                return repeated
            plan = governance.retention_plan(
                additional_protected=(registered.snapshot_locator,)
            )
            deleted = governance.apply_retention(request, plan)
            event = self.event_fields(
                "retention.tombstone_recorded",
                run.run_id,
                payload={
                    "operation": "retention.apply",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "artifact": registered.model_dump(mode="json"),
                    "dry_run": request.dry_run,
                    "deleted": list(deleted),
                    "protected": list(plan.protected),
                    "reason": request.reason,
                },
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary=(
                    "Retention dry run completed."
                    if request.dry_run
                    else "Recoverable retention cleanup completed."
                ),
                state=self._state(updated),
                next_action=self._next_action(updated),
                details={
                    "deleted": list(deleted),
                    "candidates": list(plan.candidates),
                    "protected": list(plan.protected),
                },
            )
        except GovernanceDenied as error:
            return CommandResult(code=ResultCode.POLICY_DENIED, summary=self._error_summary(error))
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    @staticmethod
    def _matching_artifact(run: RunProjection, reference: Any) -> Any:
        return next(
            (
                artifact
                for artifact in run.artifacts
                if artifact.source_locator == reference.locator
                and artifact.sha256 == reference.sha256
                and (
                    artifact.subject_id is None
                    or artifact.subject_id == reference.artifact_id
                )
            ),
            None,
        )

    def apply_trust(self, *, file: str, idempotency_key: str) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            self._governance(run).ensure_mutation_allowed()
            registry = ArtifactRegistry(self.project_root, run.run_id)
            registered = registry.register(
                ArtifactInput(kind=ArtifactKind.CAPABILITY, file=file)
            )
            capability = registry.load(registered)
            if not isinstance(capability, ExternalCapability):
                raise TypeError("trust input did not validate as an external capability")
            prior = None
            for artifact in reversed(run.artifacts):
                if artifact.kind is ArtifactKind.CAPABILITY and (
                    artifact.subject_id == capability.capability_id
                ):
                    prior = registry.load(artifact)
                    break
            if capability.status.value == "active":
                reference = capability.approval_reference
                approval_artifact = (
                    self._matching_artifact(run, reference)
                    if reference is not None
                    else None
                )
                if approval_artifact is None:
                    raise GovernanceDenied(
                        "Capability activation approval reference is not accepted."
                    )
                approval = registry.load(approval_artifact)
                subject = prior if isinstance(prior, ExternalCapability) else capability
                if (
                    not isinstance(approval, Approval)
                    or approval.decision.value != "approved"
                    or approval.subject_type != "external_capability"
                    or approval.subject_id != capability.capability_id
                    or approval.subject_digest != subject.sha256_digest()
                ):
                    raise GovernanceDenied(
                        "Capability activation approval subject binding is invalid."
                    )
            digest = RecoveryOperations.request_digest(
                {
                    "capability_id": capability.capability_id,
                    "status": capability.status.value,
                    "artifact_sha256": registered.sha256,
                }
            )
            repeated = self._idempotency_result(idempotency_key, "trust.apply", digest)
            if repeated is not None:
                return repeated
            event = self.event_fields(
                f"capability.{capability.status.value}",
                run.run_id,
                payload={
                    "operation": "trust.apply",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "artifact": registered.model_dump(mode="json"),
                    "capability": capability.model_dump(mode="json"),
                },
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary=(
                    f"Capability {capability.capability_id} is {capability.status.value}."
                ),
                state=self._state(updated),
                next_action=self._next_action(updated),
            )
        except GovernanceDenied as error:
            return CommandResult(code=ResultCode.POLICY_DENIED, summary=self._error_summary(error))
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))

    def apply_incident(self, *, file: str, idempotency_key: str) -> CommandResult:
        try:
            projection = self.projections.load_or_rebuild()
            if projection.active_run_id is None:
                return CommandResult(code=ResultCode.NOT_INITIALIZED, summary="No active run.")
            run = projection.runs[projection.active_run_id]
            registry = ArtifactRegistry(self.project_root, run.run_id)
            registered = registry.register(
                ArtifactInput(kind=ArtifactKind.INCIDENT, file=file)
            )
            incident = registry.load(registered)
            if not isinstance(incident, IncidentRecord):
                raise TypeError("incident input did not validate as an incident record")
            prior = None
            for artifact in reversed(run.artifacts):
                if artifact.kind is ArtifactKind.INCIDENT and (
                    artifact.subject_id == incident.incident_id
                ):
                    prior = registry.load(artifact)
                    break
            normalized_status = incident.status.lower()
            if normalized_status in {"contained", "resolved", "closed"} and (
                not incident.containment_actions
            ):
                raise GovernanceDenied("Incident containment requires explicit actions.")
            if normalized_status in {"resolved", "closed"}:
                reference = incident.recovery_approval_reference
                approval_artifact = (
                    self._matching_artifact(run, reference)
                    if reference is not None
                    else None
                )
                subject = prior if isinstance(prior, IncidentRecord) else incident
                approval = (
                    registry.load(approval_artifact)
                    if approval_artifact is not None
                    else None
                )
                if (
                    not isinstance(approval, Approval)
                    or approval.decision.value != "approved"
                    or approval.subject_type != "incident_recovery"
                    or approval.subject_id != incident.incident_id
                    or approval.subject_digest != subject.sha256_digest()
                ):
                    raise GovernanceDenied(
                        "Incident recovery requires accepted exact approval evidence."
                    )
            digest = RecoveryOperations.request_digest(
                {
                    "incident_id": incident.incident_id,
                    "status": incident.status,
                    "artifact_sha256": registered.sha256,
                }
            )
            repeated = self._idempotency_result(idempotency_key, "incident.apply", digest)
            if repeated is not None:
                return repeated
            event = self.event_fields(
                f"incident.{normalized_status.replace('-', '_')}",
                run.run_id,
                payload={
                    "operation": "incident.apply",
                    "idempotency_key": idempotency_key,
                    "payload_digest": digest,
                    "artifact": registered.model_dump(mode="json"),
                    "incident": incident.model_dump(mode="json"),
                },
            )
            self.journal.record(**event)
            updated = self.projections.rebuild().runs[run.run_id]
            return CommandResult(
                code=ResultCode.OK,
                summary=f"Incident {incident.incident_id} is {incident.status}.",
                state=self._state(updated),
                next_action=self._next_action(updated),
            )
        except GovernanceDenied as error:
            return CommandResult(code=ResultCode.POLICY_DENIED, summary=self._error_summary(error))
        except (JournalCorruptionError, ArtifactCorruptionError) as error:
            return CommandResult(code=ResultCode.STATE_CORRUPT, summary=self._error_summary(error))
        except (OSError, ValueError) as error:
            return CommandResult(code=ResultCode.INVALID_INPUT, summary=self._error_summary(error))
