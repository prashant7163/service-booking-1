from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import yaml

from agentic_studio.contracts import (
    PreflightCheck,
    PreflightOutcome,
    PreflightResult,
    StudioConfig,
)
from agentic_studio.persistence import (
    ArtifactCorruptionError,
    ArtifactRegistry,
    EventJournal,
    JournalCorruptionError,
)
from agentic_studio.progress import ProjectionStore


class StudioDoctor:
    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root

    def _configuration(self) -> tuple[StudioConfig | None, PreflightCheck]:
        config_path = self.project_root / "studio.yaml"
        config: StudioConfig | None = None
        if config_path.is_file():
            try:
                config = StudioConfig.model_validate(
                    yaml.safe_load(config_path.read_text(encoding="utf-8"))
                )
            except (OSError, UnicodeError, yaml.YAMLError, ValueError, TypeError):
                config = None
        valid = config is not None
        return config, PreflightCheck(
            check_id="configuration",
            scope="configuration",
            outcome=(
                PreflightOutcome.PASS
                if valid
                else PreflightOutcome.AFFECTED_SCOPE_BLOCKER
            ),
            summary="studio.yaml is valid." if valid else "studio.yaml is missing or invalid.",
            owner="project-owner",
            remediation=None if valid else "Create and validate studio.yaml.",
        )

    def _state_checks(
        self,
        config: StudioConfig | None,
    ) -> tuple[PreflightCheck, PreflightCheck]:
        journal_path = self.project_root / ".studio/journal/events.jsonl"
        if not journal_path.exists():
            unavailable = PreflightCheck(
                check_id="control-plane-integrity",
                scope="control-plane-state",
                outcome=PreflightOutcome.NOT_APPLICABLE,
                summary="No authoritative journal exists yet.",
                owner="orchestrator-tech-lead",
                remediation=None,
            )
            projection = unavailable.model_copy(
                update={
                    "check_id": "control-plane-projection",
                    "summary": "No derived projection exists yet.",
                }
            )
            return unavailable, projection

        try:
            events = EventJournal(journal_path).replay()
            if config is not None and any(
                event.project_id != config.project_id for event in events
            ):
                raise JournalCorruptionError("journal project identity differs from studio.yaml")
            sequence = events[-1].sequence if events else 0
            projection_path = self.project_root / ".studio/projection/project-status.json"
            stale = True
            if projection_path.is_file():
                try:
                    payload = json.loads(projection_path.read_text(encoding="utf-8"))
                    stale = payload.get("last_event_sequence") != sequence
                except (OSError, UnicodeError, json.JSONDecodeError, TypeError):
                    stale = True
            projected = ProjectionStore(self.project_root).load_or_rebuild()
            for run in projected.runs.values():
                registry = ArtifactRegistry(self.project_root, run.run_id)
                for artifact in run.artifacts:
                    registry.load(artifact)
        except (JournalCorruptionError, ArtifactCorruptionError, OSError, ValueError) as error:
            blocked = PreflightCheck(
                check_id="control-plane-integrity",
                scope="control-plane-state",
                outcome=PreflightOutcome.AFFECTED_SCOPE_BLOCKER,
                summary=f"Authoritative control-plane state is corrupt: {str(error)[:300]}",
                owner="orchestrator-tech-lead",
                remediation="Preserve evidence and repair the journal or digest-bound artifact.",
            )
            projection = PreflightCheck(
                check_id="control-plane-projection",
                scope="derived-state",
                outcome=PreflightOutcome.NOT_APPLICABLE,
                summary="Projection checks stopped because authoritative state is corrupt.",
                owner="orchestrator-tech-lead",
                remediation=None,
            )
            return blocked, projection

        integrity = PreflightCheck(
            check_id="control-plane-integrity",
            scope="control-plane-state",
            outcome=PreflightOutcome.PASS,
            summary="Journal identity, hash chain, and active artifact digests validate.",
            owner="orchestrator-tech-lead",
            remediation=None,
        )
        projection = PreflightCheck(
            check_id="control-plane-projection",
            scope="derived-state",
            outcome=PreflightOutcome.WARNING if stale else PreflightOutcome.PASS,
            summary=(
                "Stale or missing derived projection was rebuilt from the journal."
                if stale
                else "Derived projection matches the authoritative journal sequence."
            ),
            owner="orchestrator-tech-lead",
            remediation=None,
        )
        return integrity, projection

    def run(self, *, required_secret_references: dict[str, str]) -> PreflightResult:
        config, configuration = self._configuration()
        integrity, projection = self._state_checks(config)
        secret_check = PreflightCheck(
            check_id="secret-references",
            scope="provider-access",
            outcome=(
                PreflightOutcome.PASS
                if required_secret_references
                else PreflightOutcome.NOT_APPLICABLE
            ),
            summary=(
                "Required secret references are present by name."
                if required_secret_references
                else "No secret references are required."
            ),
            owner="project-owner",
            remediation=None,
        )
        snapshot = hashlib.sha256(self.project_root.name.encode("utf-8")).hexdigest()
        return PreflightResult(
            schema_version="1.0.0",
            result_id="preflight-current",
            project_id=config.project_id if config is not None else self.project_root.name,
            snapshot_digest=snapshot,
            recorded_at=datetime.now(UTC),
            checks=[configuration, integrity, projection, secret_check],
            secret_reference_names=sorted(required_secret_references),
        )
