from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

import yaml

from agentic_studio.contracts import (
    Approval,
    ApprovalDecision,
    EngineeringRule,
    PromptTemplate,
    QualityGatePolicy,
    ResolvedStandardRule,
    RoleCapabilityKind,
    RoleCapabilityRegistry,
    RoleCatalog,
    RuleTier,
    SkillManifest,
    SkillRegistry,
    SkillTrustStatus,
    StandardsProfile,
    WorkflowPolicy,
)


class GovernanceConflictError(RuntimeError):
    pass


class CanonicalAssetError(RuntimeError):
    pass


class SkillActivationError(RuntimeError):
    pass


class StandardsResolver:
    _priority: ClassVar[Mapping[RuleTier, int]] = {
        RuleTier.OBLIGATION: 0,
        RuleTier.HUMAN: 1,
        RuleTier.PROJECT: 2,
        RuleTier.STUDIO: 3,
        RuleTier.ROLE_SKILL: 4,
    }

    def resolve(self, rules: list[EngineeringRule]) -> tuple[ResolvedStandardRule, ...]:
        grouped: dict[str, list[EngineeringRule]] = defaultdict(list)
        for rule in rules:
            grouped[rule.rule_id].append(rule)
        resolved: list[ResolvedStandardRule] = []
        for rule_id, candidates in sorted(grouped.items()):
            non_negotiable = [rule for rule in candidates if rule.non_negotiable]
            if non_negotiable and any(
                candidate.statement != non_negotiable[0].statement for candidate in candidates
            ):
                raise GovernanceConflictError(
                    f"non-negotiable rule {rule_id!r} cannot be weakened or replaced"
                )
            winner = min(candidates, key=lambda rule: self._priority[rule.tier])
            resolved.append(
                ResolvedStandardRule(
                    rule_id=rule_id,
                    effective_statement=winner.statement,
                    winning_tier=winner.tier,
                    source=winner.source,
                    shadowed_sources=[rule.source for rule in candidates if rule is not winner],
                    rationale="Selected by deterministic governance precedence.",
                )
            )
        return tuple(resolved)


class SkillTrustController:
    def activate(self, skill: SkillManifest, approval: Approval | None = None) -> SkillManifest:
        if skill.trust_status is not SkillTrustStatus.TRUSTED_ACTIVE:
            raise SkillActivationError("skill is not trusted_active")
        if skill.provenance == "studio":
            return skill
        if approval is None or approval.decision is not ApprovalDecision.APPROVED:
            raise SkillActivationError("project skill activation requires approval")
        if approval.subject_type != "skill_manifest" or approval.subject_id != skill.skill_id:
            raise SkillActivationError("approval subject does not match skill")
        if approval.subject_digest != skill.sha256_digest():
            raise SkillActivationError("approval digest does not match skill")
        return skill


@dataclass(frozen=True, slots=True)
class CanonicalAssets:
    role_catalog: RoleCatalog
    capability_registry: RoleCapabilityRegistry
    skill_registry: SkillRegistry
    standards_profile: StandardsProfile
    workflow_policy: WorkflowPolicy
    quality_gate_policy: QualityGatePolicy
    prompt_template: PromptTemplate


class CanonicalAssetLoader:
    def _load(self, path: Path) -> object:
        with path.open(encoding="utf-8") as stream:
            return yaml.safe_load(stream)

    def load_tree(self, shared_root: Path) -> CanonicalAssets:
        role_catalog = RoleCatalog.model_validate(
            self._load(shared_root / "roles" / "catalog.yaml")
        )
        capability_registry = RoleCapabilityRegistry.model_validate(
            self._load(shared_root / "roles" / "capabilities.yaml")
        )
        self._validate_role_capabilities(role_catalog, capability_registry)
        return CanonicalAssets(
            role_catalog=role_catalog,
            capability_registry=capability_registry,
            skill_registry=SkillRegistry.model_validate(
                self._load(shared_root / "skills" / "catalog.yaml")
            ),
            standards_profile=StandardsProfile.model_validate(
                self._load(shared_root / "standards" / "baseline.yaml")
            ),
            workflow_policy=WorkflowPolicy.model_validate(
                self._load(shared_root / "policies" / "workflow.yaml")
            ),
            quality_gate_policy=QualityGatePolicy.model_validate(
                self._load(shared_root / "policies" / "quality-gates.yaml")
            ),
            prompt_template=PromptTemplate.model_validate(
                self._load(shared_root / "prompts" / "model-request.yaml")
            ),
        )

    def _validate_role_capabilities(
        self,
        role_catalog: RoleCatalog,
        capability_registry: RoleCapabilityRegistry,
    ) -> None:
        roles = {role.role_id for role in role_catalog.roles}
        capabilities = {
            capability.capability_id: capability for capability in capability_registry.capabilities
        }
        for capability in capability_registry.capabilities:
            unknown_roles = set(capability.applicable_roles) - roles
            if unknown_roles:
                raise CanonicalAssetError(
                    f"capability {capability.capability_id!r} names unknown roles: "
                    f"{', '.join(sorted(unknown_roles))}"
                )
        for role in role_catalog.roles:
            references = [
                (capability_id, RoleCapabilityKind.AUTHORITY) for capability_id in role.authority
            ] + [(capability_id, RoleCapabilityKind.BOUNDARY) for capability_id in role.boundaries]
            for capability_id, expected_kind in references:
                registered_capability = capabilities.get(capability_id)
                if registered_capability is None:
                    raise CanonicalAssetError(
                        f"role {role.role_id!r} references undefined capability {capability_id!r}"
                    )
                if registered_capability.kind is not expected_kind:
                    raise CanonicalAssetError(
                        f"role {role.role_id!r} uses {capability_id!r} as "
                        f"{expected_kind.value}, but it is {registered_capability.kind.value}"
                    )
                if role.role_id not in registered_capability.applicable_roles:
                    raise CanonicalAssetError(
                        f"capability {capability_id!r} is not applicable to role {role.role_id!r}"
                    )
