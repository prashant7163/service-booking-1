from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from agentic_studio.contracts import (
    OperatorControl,
)
from agentic_studio.persistence import EventJournal
from agentic_studio.progress import RunProjection

from .operations import OperatorControlState


class GovernanceDenied(ValueError):
    pass


class RetentionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    reason: str = Field(min_length=1, max_length=500)
    dry_run: bool = False
    recoverable: bool = True


@dataclass(frozen=True, slots=True)
class RetentionPlan:
    candidates: tuple[str, ...]
    protected: tuple[str, ...]


class GovernanceOperations:
    def __init__(
        self,
        project_root: Path,
        journal: EventJournal,
        run: RunProjection,
    ) -> None:
        self.project_root = project_root
        self.journal = journal
        self.run = run

    def active_controls(self) -> tuple[OperatorControl, ...]:
        controls: dict[str, OperatorControl] = {}
        for event in self.journal.replay():
            if event.run_id != self.run.run_id:
                continue
            payload = event.model_dump(mode="json")["payload"]
            if event.event_type == "control.applied":
                control_payload = payload.get("control")
                if not isinstance(control_payload, dict):
                    raise GovernanceDenied("Control event is missing its typed control payload.")
                control = OperatorControl.model_validate(control_payload)
                controls[control.control_id] = control
            elif event.event_type == "control.cleared":
                control_id = payload.get("control_id")
                if isinstance(control_id, str):
                    controls.pop(control_id, None)
        if not controls:
            return ()
        state = OperatorControlState()
        for control in controls.values():
            state.apply(control)
        active = state.active
        remaining = sorted(
            (item for item in controls.values() if item.control_id != active.control_id),
            key=lambda item: item.control_id,
        )
        return (active, *remaining)

    def ensure_mutation_allowed(self) -> None:
        controls = self.active_controls()
        if controls:
            active = controls[0]
            raise GovernanceDenied(
                f"Mutation is blocked by active {active.action.value} control {active.control_id}."
            )

    def retention_plan(
        self,
        *,
        additional_protected: tuple[str, ...] = (),
    ) -> RetentionPlan:
        artifact_directory = (
            self.project_root / ".studio" / "runs" / self.run.run_id / "artifacts"
        )
        protected = {
            artifact.snapshot_locator for artifact in self.run.artifacts
        } | set(additional_protected)
        candidates: list[str] = []
        if artifact_directory.exists():
            for path in sorted(artifact_directory.iterdir()):
                if path.is_symlink():
                    raise GovernanceDenied("Retention refuses symbolic links.")
                if not path.is_file() or path.name.startswith("."):
                    continue
                locator = path.relative_to(self.project_root).as_posix()
                if locator not in protected:
                    candidates.append(locator)
        return RetentionPlan(tuple(candidates), tuple(sorted(protected)))

    def apply_retention(
        self,
        request: RetentionRequest,
        plan: RetentionPlan,
    ) -> tuple[str, ...]:
        if request.dry_run:
            return ()
        moved: list[str] = []
        tombstone_root = (
            self.project_root
            / ".studio"
            / "runs"
            / self.run.run_id
            / "evidence"
            / "retention-tombstones"
        )
        tombstone_root.mkdir(parents=True, exist_ok=True)
        for locator in plan.candidates:
            source = self.project_root / locator
            if source.is_symlink() or not source.is_file():
                raise GovernanceDenied("Retention candidate changed during cleanup.")
            destination = tombstone_root / source.name
            if destination.exists() or destination.is_symlink():
                raise GovernanceDenied("Retention tombstone already exists.")
            if request.recoverable:
                os.replace(source, destination)
            else:
                source.unlink()
            moved.append(locator)
        return tuple(moved)


def capability_transition_event(
    action: Literal["registered", "activated", "revoked", "quarantined"],
) -> str:
    return f"capability.{action}"
