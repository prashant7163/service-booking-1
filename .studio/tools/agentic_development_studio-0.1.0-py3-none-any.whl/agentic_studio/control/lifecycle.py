from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass

from agentic_studio.contracts.governance import WorkflowPolicy
from agentic_studio.contracts.workflow import TaskLifecycle

from .policy import EVIDENCE_REQUIRED_RECOVERY, TASK_TRANSITIONS


@dataclass(frozen=True, slots=True)
class TransitionDecision:
    allowed: bool
    reason_code: str
    current: TaskLifecycle
    requested: TaskLifecycle
    evidence_ids: tuple[str, ...]


class LifecycleController:
    def __init__(
        self, transitions: Mapping[TaskLifecycle, frozenset[TaskLifecycle]] | None = None
    ) -> None:
        self._transitions = TASK_TRANSITIONS if transitions is None else transitions

    @classmethod
    def from_policy(cls, policy: WorkflowPolicy) -> LifecycleController:
        transitions = {
            TaskLifecycle(current): frozenset(TaskLifecycle(target) for target in targets)
            for current, targets in policy.transitions.items()
        }
        if set(transitions) != set(TaskLifecycle):
            raise ValueError("workflow policy must define every task lifecycle state")
        return cls(transitions)

    def decide(
        self,
        current: TaskLifecycle,
        requested: TaskLifecycle,
        *,
        evidence_ids: Iterable[str] = (),
    ) -> TransitionDecision:
        evidence = tuple(evidence_ids)
        if requested not in self._transitions[current]:
            return TransitionDecision(False, "transition_not_allowed", current, requested, evidence)
        if (current, requested) in EVIDENCE_REQUIRED_RECOVERY and not evidence:
            return TransitionDecision(
                False, "resolution_evidence_required", current, requested, evidence
            )
        return TransitionDecision(True, "allowed", current, requested, evidence)
