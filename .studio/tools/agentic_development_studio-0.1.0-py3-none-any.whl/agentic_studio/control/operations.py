from __future__ import annotations

from collections.abc import Mapping
from typing import ClassVar

from agentic_studio.contracts import (
    Approval,
    ApprovalDecision,
    CapabilityStatus,
    ExternalCapability,
    OperatorAction,
    OperatorControl,
)


class OperatorControlState:
    _priority: ClassVar[Mapping[OperatorAction, int]] = {
        OperatorAction.PAUSE: 0,
        OperatorAction.CANCEL: 1,
        OperatorAction.REVOKE_PERMISSION: 2,
        OperatorAction.REVOKE_LEASE: 3,
        OperatorAction.QUARANTINE_OUTBOUND: 4,
        OperatorAction.STOP_ALL: 5,
    }

    def __init__(self) -> None:
        self._controls: dict[str, OperatorControl] = {}

    def apply(self, control: OperatorControl) -> None:
        self._controls[control.control_id] = control

    @property
    def active(self) -> OperatorControl:
        if not self._controls:
            raise LookupError("no active operator control")
        return max(self._controls.values(), key=lambda item: self._priority[item.action])

    @property
    def consequential_side_effect_allowed(self) -> bool:
        return not self._controls

    def clear(self, control_id: str, approval: Approval | None) -> None:
        control = self._controls.get(control_id)
        if control is None:
            raise LookupError(control_id)
        if (
            approval is None
            or approval.decision is not ApprovalDecision.APPROVED
            or approval.subject_type != "operator_control_clearance"
            or approval.subject_id != control_id
            or approval.subject_digest != control.sha256_digest()
        ):
            raise PermissionError("operator control clearance requires exact human approval")
        del self._controls[control_id]


class CapabilityTrustRegistry:
    def __init__(self, capabilities: list[ExternalCapability]) -> None:
        self._capabilities = {item.capability_id: item for item in capabilities}

    def get(self, capability_id: str) -> ExternalCapability:
        return self._capabilities[capability_id]

    def revoke(self, capability_id: str) -> ExternalCapability:
        updated = self.get(capability_id).model_copy(update={"status": CapabilityStatus.REVOKED})
        self._capabilities[capability_id] = updated
        return updated

    def activate(self, capability_id: str, approval: Approval | None) -> ExternalCapability:
        current = self.get(capability_id)
        if current.status is CapabilityStatus.ACTIVE:
            return current
        if (
            approval is None
            or approval.decision is not ApprovalDecision.APPROVED
            or approval.subject_type != "external_capability"
            or approval.subject_id != capability_id
            or approval.subject_digest != current.sha256_digest()
        ):
            raise PermissionError("capability reactivation requires exact human approval")
        updated = current.model_copy(update={"status": CapabilityStatus.ACTIVE})
        self._capabilities[capability_id] = updated
        return updated
