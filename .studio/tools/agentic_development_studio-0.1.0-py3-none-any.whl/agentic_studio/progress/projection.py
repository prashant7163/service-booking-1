from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType

from agentic_studio.contracts import Event


@dataclass(frozen=True, slots=True)
class ProgressProjection:
    project_id: str
    run_id: str
    task_states: Mapping[str, str]
    session_ids: tuple[str, ...]
    last_event_sequence: int


def rebuild_projection(events: Sequence[Event]) -> ProgressProjection:
    if not events:
        raise ValueError("projection requires at least one journal event")
    task_states: dict[str, str] = {}
    sessions: list[str] = []
    for event in events:
        if event.session_id is not None and event.session_id not in sessions:
            sessions.append(event.session_id)
        if event.event_type == "task.transition" and event.task_id is not None:
            state = event.payload.get("state")
            if not isinstance(state, str):
                raise ValueError("task transition event requires a string state")
            task_states[event.task_id] = state
    return ProgressProjection(
        project_id=events[-1].project_id,
        run_id=events[-1].run_id,
        task_states=MappingProxyType(task_states),
        session_ids=tuple(sessions),
        last_event_sequence=events[-1].sequence,
    )
